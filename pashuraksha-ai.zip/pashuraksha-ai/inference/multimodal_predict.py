"""Multimodal fusion inference (spec §24, §25, §26, §27, §28, §31, §52, §55).

Transparent weighted fusion of:
  - image disease probabilities
  - clinical disease probabilities
  - health-history indicators
  - anomaly score

Produces a unified screening output with:
  - screening_prediction
  - top_disease_probabilities
  - risk_score (0-100) and risk_level
  - model_agreement
  - contributing_factors
  - recommended_action, vet_referral, lab_confirmation
  - disclaimer

Usage:
    python inference/multimodal_predict.py \
        --image cow.jpg \
        --age 4 --temperature 40.2 \
        --symptoms "fever,loss_of_appetite" --breed "Gir"
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402

log = get_logger("multimodal")


# ---------------------------------------------------------------------------
# Risk scoring
# ---------------------------------------------------------------------------

def get_risk_level(score: int) -> str:
    """Map 0–100 score to a band label (spec §27)."""
    if score <= 30:
        return "Low"
    if score <= 60:
        return "Moderate"
    if score <= 80:
        return "High"
    return "Critical"


def compute_risk_score(
    image_confidence: float,
    clinical_risk_probability: float,
    anomaly_score: float,
    unknown_pattern: bool,
    symptom_severity_score: float = 0.0,
    safety_override: bool = False,
    unknown_pattern_urgency_bonus: int = 15,
) -> int:
    """Combine signals into a 0–100 risk score.

    The score represents screening urgency/risk — NOT diagnostic certainty.
    Unknown patterns increase urgency while reducing certainty (spec §27).
    """
    base = max(image_confidence, clinical_risk_probability) * 100
    anomaly_component = min(anomaly_score * 100, 20.0)  # cap at 20 points
    score = base * 0.6 + anomaly_component * 0.2 + symptom_severity_score * 100 * 0.2
    if unknown_pattern:
        score += unknown_pattern_urgency_bonus
    if safety_override:
        # Severe symptoms detected — force minimum threshold into High/Critical
        score = max(score, 75.0)
    return int(max(0, min(100, round(score))))


# ---------------------------------------------------------------------------
# Safety override (spec §28)
# ---------------------------------------------------------------------------

def check_safety_override(features: dict, cfg: dict) -> tuple[bool, list[str]]:
    """Return (override_triggered, list_of_triggered_signals).

    Only fires when severe-symptom fields exist in the input — does NOT fabricate
    symptoms (spec §28).
    """
    safety_cfg = cfg.get("fusion", {}).get("safety", {})
    triggers: list[str] = []

    # Extreme body temperature
    extreme_t = safety_cfg.get("extreme_temperature_celsius", 41.0)
    t_value = features.get("temperature")
    if t_value is not None:
        try:
            t = float(t_value)
            if t >= extreme_t:
                triggers.append(f"extreme_temperature={t}C")
        except (TypeError, ValueError):
            pass

    # Severe symptom keywords
    keywords = set(safety_cfg.get("severe_symptom_keywords", []))
    sym_value = features.get("symptoms") or features.get("symptom") or ""
    if isinstance(sym_value, str):
        sym_tokens = {t.strip().lower() for t in sym_value.replace(";", ",").replace("|", ",").split(",")}
        matched = sym_tokens & keywords
        triggers.extend(matched)

    return bool(triggers), triggers


# ---------------------------------------------------------------------------
# Model agreement
# ---------------------------------------------------------------------------

def compute_model_agreement(
    image_top: dict[str, float],
    clinical_top: dict[str, float],
    disagreement_threshold: float = 0.10,
) -> tuple[str, str | None, str | None]:
    """Determine whether image and clinical models agree (spec §26).

    Returns (agreement_label, image_top_class, clinical_top_class).
    """
    if not image_top and not clinical_top:
        return "Unknown", None, None
    img_class = max(image_top, key=image_top.get) if image_top else None
    clin_class = max(clinical_top, key=clinical_top.get) if clinical_top else None
    if img_class is None or clin_class is None:
        return "Partial", img_class, clin_class
    if img_class == clin_class:
        return "High", img_class, clin_class
    img_p = image_top[img_class]
    clin_p = clinical_top[clin_class]
    if abs(img_p - clin_p) < disagreement_threshold:
        return "Moderate", img_class, clin_class
    return "Low", img_class, clin_class


# ---------------------------------------------------------------------------
# Recommendation logic (spec §33)
# ---------------------------------------------------------------------------

def recommend_action(
    risk_level: str,
    unknown_pattern: bool,
    agreement: str,
    safety_override: bool,
) -> tuple[str, bool, str]:
    """Return (recommendation, vet_referral, lab_confirmation_message)."""
    if safety_override:
        return ("Urgent veterinary assessment recommended.", True,
                "Recommended where clinically indicated.")
    if unknown_pattern:
        return ("Unknown pattern — veterinary/lab confirmation required.", True,
                "Recommended where clinically indicated.")
    if agreement == "Low":
        return ("Conflicting AI screening signals detected. Veterinary assessment recommended.", True,
                "Recommended where clinically indicated.")
    if risk_level == "Critical":
        return ("Urgent veterinary assessment recommended.", True,
                "Recommended where clinically indicated.")
    if risk_level == "High":
        return ("Veterinary consultation recommended.", True,
                "Recommended where clinically indicated.")
    if risk_level == "Moderate":
        return ("Veterinary consultation recommended if symptoms persist.", False,
                "Recommended where clinically indicated.")
    return ("Monitor.", False,
            "Lab confirmation recommended only if clinically indicated.")


# ---------------------------------------------------------------------------
# Main fusion entrypoint
# ---------------------------------------------------------------------------

def multimodal_predict(
    image_path: Path | None = None,
    clinical_features: dict | None = None,
    model_dir: Path | None = None,
    image_model_path: Path | None = None,
    anomaly_model_path: Path | None = None,
    confidence_threshold: float = 0.55,
    config_path: Path | None = None,
):
    """Combine image + clinical + anomaly signals into a single screening report."""
    if config_path is None:
        config_path = PROJECT_ROOT / "configs" / "default.yaml"
    with open(config_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    clinical_features = clinical_features or {}
    image_probs: dict[str, float] = {}
    image_confidence = 0.0
    image_label: str | None = None
    unknown_pattern = False
    anomaly_score = 0.0
    image_features_summary: list[str] = []

    # --- Image branch ---
    if image_path and Path(image_path).exists():
        from inference.image_predict import predict_image
        image_result = predict_image(
            image_path=Path(image_path),
            model_path=image_model_path or (PROJECT_ROOT / "models" / "image_model" / "best_model.pth"),
            anomaly_path=anomaly_model_path or (PROJECT_ROOT / "models" / "anomaly_model" / "image_anomaly.joblib"),
            confidence_threshold=confidence_threshold,
        )
        for tp in image_result.get("top_predictions", []):
            image_probs[tp["class"]] = tp["probability"]
        image_confidence = float(image_result.get("confidence", 0.0))
        image_label = image_result.get("prediction")
        unknown_pattern = bool(image_result.get("unknown_pattern"))
        anomaly_score = float(image_result.get("anomaly_score") or 0.0)
        if image_label and not image_label.startswith("Uncertain"):
            image_features_summary.append(
                f"Image pattern associated with {image_label} (conf={image_confidence:.2f})"
            )
    elif image_path:
        log.warning("Image path provided but file does not exist: %s", image_path)

    # --- Clinical branch ---
    clinical_probs: dict[str, float] = {}
    clinical_risk_probability = 0.0
    clinical_label: str | None = None
    clinical_features_used: list[str] = []
    if clinical_features:
        try:
            from inference.clinical_predict import predict_clinical
            clinical_result = predict_clinical(clinical_features, model_dir=model_dir or (PROJECT_ROOT / "models" / "clinical_model"))
            clinical_probs = clinical_result.get("disease_probabilities", {})
            clinical_risk_probability = float(clinical_result.get("clinical_risk_probability", 0.0))
            clinical_label = clinical_result.get("predicted_condition")
            if clinical_label:
                clinical_features_used.append(
                    f"Clinical evidence associated with {clinical_label} (p={clinical_risk_probability:.2f})"
                )
        except FileNotFoundError as e:
            log.warning("Clinical model unavailable: %s", e)

    # --- Safety override (spec §28) ---
    safety_override, safety_triggers = check_safety_override(clinical_features, cfg)

    # --- Model agreement (spec §26) ---
    fusion_cfg = cfg.get("fusion", {})
    agreement, img_top, clin_top = compute_model_agreement(
        image_probs, clinical_probs,
        disagreement_threshold=fusion_cfg.get("disagreement_threshold", 0.10),
    )

    # --- Fusion: transparent weighted averaging of probabilities ---
    weights = fusion_cfg.get("weights", {"image": 0.5, "clinical": 0.5})
    fused: dict[str, float] = {}
    all_classes = set(image_probs) | set(clinical_probs)
    w_img = float(weights.get("image", 0.0))
    w_cli = float(weights.get("clinical", 0.0))
    total_w = w_img + w_cli
    if total_w > 0:
        for cls in all_classes:
            fused[cls] = (
                image_probs.get(cls, 0.0) * w_img
                + clinical_probs.get(cls, 0.0) * w_cli
            ) / total_w

    # Pick the screening prediction
    if unknown_pattern:
        screening_prediction = "Unknown / Unusual Pattern"
    elif safety_override:
        screening_prediction = "Severe clinical presentation — veterinary assessment required"
    elif fused:
        screening_prediction = f"Possible {max(fused, key=fused.get)}"
    elif image_label:
        screening_prediction = f"Possible {image_label}"
    elif clinical_label:
        screening_prediction = f"Possible {clinical_label}"
    else:
        screening_prediction = "No screening signal available"

    # Top-k probabilities
    top_disease = dict(sorted(fused.items(), key=lambda kv: -kv[1])[:3])

    # --- Risk score ---
    symptom_severity_score = 0.0
    # Crude heuristic: count severe symptom tokens
    sym_str = clinical_features.get("symptoms") or ""
    if isinstance(sym_str, str):
        sym_tokens = [t.strip().lower() for t in sym_str.replace(";", ",").replace("|", ",").split(",") if t.strip()]
        severe_keywords = set(fusion_cfg.get("safety", {}).get("severe_symptom_keywords", []))
        n_severe = sum(1 for t in sym_tokens if t in severe_keywords)
        symptom_severity_score = min(n_severe / 3.0, 1.0)

    risk_score = compute_risk_score(
        image_confidence=image_confidence,
        clinical_risk_probability=clinical_risk_probability,
        anomaly_score=anomaly_score,
        unknown_pattern=unknown_pattern,
        symptom_severity_score=symptom_severity_score,
        safety_override=safety_override,
        unknown_pattern_urgency_bonus=cfg.get("risk", {}).get("unknown_pattern_urgency_bonus", 15),
    )
    risk_level = get_risk_level(risk_score)

    # --- Recommendation ---
    recommendation, vet_referral, lab_confirmation = recommend_action(
        risk_level=risk_level,
        unknown_pattern=unknown_pattern,
        agreement=agreement,
        safety_override=safety_override,
    )

    # --- Contributing factors (spec §31) ---
    contributing_factors: list[str] = []
    contributing_factors.extend(image_features_summary)
    contributing_factors.extend(clinical_features_used)
    if unknown_pattern:
        contributing_factors.append(
            "Anomaly detector flagged the input as substantially different from training patterns."
        )
    if agreement == "Low":
        contributing_factors.append("Image and clinical models disagree on the most likely disease.")
    if safety_override:
        contributing_factors.append(f"Safety override triggered by: {', '.join(safety_triggers)}")
    # Specific clinical features
    for k in ["temperature", "age", "breed"]:
        if k in clinical_features and clinical_features[k] is not None:
            if k == "temperature":
                try:
                    t = float(clinical_features[k])
                    if t >= 39.5:
                        contributing_factors.append(f"Elevated body temperature ({t} C)")
                except (TypeError, ValueError):
                    pass
    if "symptoms" in clinical_features and clinical_features["symptoms"]:
        contributing_factors.append(f"Reported symptoms: {clinical_features['symptoms']}")

    # Deduplicate while preserving order
    seen = set()
    contributing_factors = [c for c in contributing_factors if not (c in seen or seen.add(c))]

    return {
        "screening_prediction": screening_prediction,
        "top_disease_probabilities": {k: round(v, 4) for k, v in top_disease.items()},
        "image_confidence": round(image_confidence, 4),
        "clinical_probability": round(clinical_risk_probability, 4),
        "unknown_pattern": unknown_pattern,
        "anomaly_score": round(anomaly_score, 4),
        "risk_score": risk_score,
        "risk_level": risk_level,
        "model_agreement": agreement,
        "image_top_class": img_top,
        "clinical_top_class": clin_top,
        "contributing_factors": contributing_factors,
        "recommended_action": recommendation,
        "vet_referral": vet_referral,
        "lab_confirmation": lab_confirmation,
        "safety_override_triggered": safety_override,
        "disclaimer": "This is an AI screening result and not a confirmed veterinary diagnosis.",
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Multimodal screening prediction (spec §24–§33).")
    parser.add_argument("--image", type=str, default=None)
    parser.add_argument("--model-dir", type=str, default="models/clinical_model")
    parser.add_argument("--threshold", type=float, default=0.55)
    args, unknown = parser.parse_known_args(argv)

    clinical_features: dict = {}
    i = 0
    while i < len(unknown):
        tok = unknown[i]
        if tok.startswith("--"):
            key = tok[2:]
            if i + 1 < len(unknown) and not unknown[i + 1].startswith("--"):
                clinical_features[key] = unknown[i + 1]
                i += 2
                continue
            clinical_features[key] = True
            i += 1
        else:
            i += 1

    result = multimodal_predict(
        image_path=Path(args.image) if args.image else None,
        clinical_features=clinical_features,
        model_dir=Path(args.model_dir),
        confidence_threshold=args.threshold,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
