"""Single-image inference (spec §13, §14, §22, §55).

Loads the trained MobileNetV3 + (optional) anomaly detector and produces:
  - prediction (or "Uncertain" if below confidence_threshold)
  - confidence
  - top-k probabilities
  - unknown pattern score / flag
  - screening recommendation

Usage:
    python inference/image_predict.py --image sample.jpg
    python inference/image_predict.py --image sample.jpg --threshold 0.55
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.device import get_device  # noqa: E402
from utils.logger import get_logger  # noqa: E402

log = get_logger("image_predict")

DEFAULT_MODEL = PROJECT_ROOT / "models" / "image_model" / "best_model.pth"
DEFAULT_ANOMALY = PROJECT_ROOT / "models" / "anomaly_model" / "image_anomaly.joblib"


def load_image_model(model_path: Path, device: str = "cpu"):
    """Load the saved image model and return (model, payload)."""
    import torch
    from torchvision import models

    payload = torch.load(model_path, map_location=device, weights_only=False)
    class_names = payload["class_names"]
    n_classes = len(class_names)
    model = models.mobilenet_v3_large(weights=None)
    in_features = model.classifier[-1].in_features
    model.classifier[-1] = torch.nn.Linear(in_features, n_classes)
    model.load_state_dict(payload["model_state_dict"])
    model.to(device).eval()

    # Build a feature-extractor (penultimate layer) for anomaly detection
    feature_extractor = models.mobilenet_v3_large(weights=None)
    feature_extractor.classifier[-1] = torch.nn.Linear(in_features, n_classes)
    feature_extractor.load_state_dict(payload["model_state_dict"])
    feature_extractor.to(device).eval()
    feature_extractor.classifier = torch.nn.Identity()
    return model, feature_extractor, payload


def preprocess_image(image_path: Path, cfg: dict):
    """Load and preprocess a single image to a tensor of shape (1, 3, H, W)."""
    import torch
    from PIL import Image
    from data_processing.prepare_images import build_inference_transform

    tf = build_inference_transform(cfg)
    img = Image.open(image_path).convert("RGB")
    return tf(img).unsqueeze(0)


def compute_anomaly_score(feature_extractor, image_tensor, anomaly_path: Path, device: str):
    """Compute anomaly score from embeddings + a saved IsolationForest/LOF model."""
    import joblib
    import numpy as np
    import torch

    if not anomaly_path.exists():
        return None, False
    payload = joblib.load(anomaly_path)
    detector = payload["model"]
    threshold = payload["threshold"]
    with torch.no_grad():
        emb = feature_extractor(image_tensor.to(device)).cpu().numpy()
    score = float(-detector.score_samples(emb)[0])
    unknown = score > threshold
    return score, unknown


def predict_image(
    image_path: Path,
    model_path: Path = DEFAULT_MODEL,
    anomaly_path: Path = DEFAULT_ANOMALY,
    confidence_threshold: float = 0.55,
    top_k: int = 3,
    device_pref: str = "auto",
):
    """Run a full image-only prediction with safety handling (spec §13, §55)."""
    import torch
    import yaml

    if not model_path.exists():
        raise FileNotFoundError(
            f"Image model not found at {model_path}. Train the model first via "
            "training/train_image.py."
        )
    device = get_device(device_pref, verbose=False)
    model, feature_extractor, payload = load_image_model(model_path, device=device)
    class_names = payload["class_names"]

    with open(PROJECT_ROOT / "configs" / "default.yaml", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    image_tensor = preprocess_image(image_path, cfg)
    with torch.no_grad():
        logits = model(image_tensor.to(device))
        # Apply temperature scaling if present
        temperature = payload.get("temperature")
        if temperature and temperature > 0:
            logits = logits / temperature
        probs = torch.softmax(logits, dim=1)[0]

    probs_np = probs.cpu().numpy()
    top_idx = probs_np.argsort()[::-1][:top_k]
    top_predictions = [
        {"class": class_names[i], "probability": float(probs_np[i])}
        for i in top_idx
    ]
    pred_idx = int(top_idx[0])
    confidence = float(probs_np[pred_idx])
    prediction_label = class_names[pred_idx]

    # Anomaly detection
    anomaly_score, unknown_flag = compute_anomaly_score(
        feature_extractor, image_tensor, anomaly_path, device,
    )
    if anomaly_score is None:
        anomaly_score = 0.0
        unknown_flag = False

    # Low-confidence handling (spec §13, §55)
    uncertain = confidence < confidence_threshold or unknown_flag
    if uncertain:
        prediction_label = "Uncertain / Unknown Pattern"

    # Screening recommendation
    if unknown_flag:
        recommendation = (
            "AI could not reliably match this case to known patterns. "
            "Veterinary examination and/or laboratory confirmation is recommended."
        )
    elif confidence < confidence_threshold:
        recommendation = (
            "Low-confidence screening result. Veterinary consultation recommended."
        )
    else:
        recommendation = (
            "AI screening result. Veterinary confirmation may be required for "
            "definitive diagnosis."
        )

    result = {
        "prediction": prediction_label,
        "confidence": confidence,
        "top_predictions": top_predictions,
        "unknown_pattern": bool(unknown_flag),
        "anomaly_score": anomaly_score,
        "uncertain": uncertain,
        "screening_note": recommendation,
        "disclaimer": "This is an AI screening result and not a confirmed veterinary diagnosis.",
    }
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Image-only prediction (spec §14).")
    parser.add_argument("--image", required=True, type=str)
    parser.add_argument("--model", type=str, default=str(DEFAULT_MODEL))
    parser.add_argument("--anomaly-model", type=str, default=str(DEFAULT_ANOMALY))
    parser.add_argument("--threshold", type=float, default=0.55)
    parser.add_argument("--top-k", type=int, default=3)
    args = parser.parse_args(argv)

    result = predict_image(
        image_path=Path(args.image),
        model_path=Path(args.model),
        anomaly_path=Path(args.anomaly_model),
        confidence_threshold=args.threshold,
        top_k=args.top_k,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
