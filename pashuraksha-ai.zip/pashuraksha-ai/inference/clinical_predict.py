"""Clinical-only inference (spec §20).

Loads the trained XGBoost clinical model + preprocessor + label encoder and
returns disease probabilities + clinical risk probability / score.

Usage:
    python inference/clinical_predict.py \
        --age 4 --temperature 40.2 --symptoms "fever,loss_of_appetite" \
        --breed "Gir"
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402

log = get_logger("clinical_predict")

DEFAULT_MODEL_DIR = PROJECT_ROOT / "models" / "clinical_model"


def load_clinical_artifacts(model_dir: Path = DEFAULT_MODEL_DIR):
    import joblib
    if not (model_dir / "model.joblib").exists():
        raise FileNotFoundError(
            f"Clinical model not found in {model_dir}. Run training/train_clinical.py first."
        )
    return {
        "model": joblib.load(model_dir / "model.joblib"),
        "preprocessor": joblib.load(model_dir / "preprocessor.joblib"),
        "symptom_encoder": joblib.load(model_dir / "symptom_encoder.joblib"),
        "label_encoder": joblib.load(model_dir / "label_encoder.joblib"),
        "feature_groups": joblib.load(model_dir / "feature_groups.joblib"),
    }


def build_input_row(features: dict, feature_groups: dict) -> "pandas.DataFrame":
    """Construct a single-row DataFrame matching the training schema.

    Only accepts features that were present during training. Unknown keys are
    ignored with a warning (spec §51 — only accept features supported by the
    real trained clinical model).
    """
    import pandas as pd
    expected_cols = (
        feature_groups["numeric"]
        + feature_groups["categorical"]
        + feature_groups["multivalue"]
    )
    row = {c: None for c in expected_cols}
    for k, v in features.items():
        if k in row:
            row[k] = v
        else:
            log.warning("Ignoring unknown clinical feature: %s", k)
    return pd.DataFrame([row])


def predict_clinical(features: dict, model_dir: Path = DEFAULT_MODEL_DIR):
    import numpy as np
    artifacts = load_clinical_artifacts(model_dir)
    model = artifacts["model"]
    pre = artifacts["preprocessor"]
    sym_enc = artifacts["symptom_encoder"]
    le = artifacts["label_encoder"]
    groups = artifacts["feature_groups"]

    X_row = build_input_row(features, groups)
    main_features = pre.transform(X_row)
    if groups["multivalue"]:
        sym_df = sym_enc.transform(X_row)
        combined = np.hstack([main_features, sym_df.values])
    else:
        combined = main_features

    proba = model.predict_proba(combined)[0]
    classes = list(le.classes_)
    disease_probs = {str(classes[i]): float(proba[i]) for i in range(len(classes))}

    if len(classes) == 2:
        # Binary problem — assume class 1 is "at-risk"
        clinical_risk_probability = float(proba[1])
        predicted_condition = str(classes[int(proba.argmax())])
    else:
        idx = int(proba.argmax())
        clinical_risk_probability = float(proba[idx])
        predicted_condition = str(classes[idx])

    risk_score = int(round(clinical_risk_probability * 100))

    return {
        "predicted_condition": predicted_condition,
        "disease_probabilities": disease_probs,
        "clinical_risk_probability": clinical_risk_probability,
        "clinical_risk_score": risk_score,
        "disclaimer": "Prototype clinical screening — not a confirmed medical diagnosis.",
    }


def main(argv: list[str] | None = None) -> int:
    """Parse arbitrary --key value clinical features from the CLI."""
    parser = argparse.ArgumentParser(description="Clinical prediction (spec §20).")
    parser.add_argument("--model-dir", type=str, default=str(DEFAULT_MODEL_DIR))
    args, unknown = parser.parse_known_args(argv)

    # Parse --key value pairs from the remaining args
    features: dict = {}
    i = 0
    while i < len(unknown):
        tok = unknown[i]
        if tok.startswith("--"):
            key = tok[2:]
            if i + 1 < len(unknown) and not unknown[i + 1].startswith("--"):
                features[key] = unknown[i + 1]
                i += 2
                continue
            features[key] = True
            i += 1
        else:
            i += 1

    if not features:
        parser.print_help()
        print("\nExample:\n  python inference/clinical_predict.py --age 4 --temperature 40.2 "
              "--symptoms 'fever,loss_of_appetite' --breed 'Gir'")
        return 1

    result = predict_clinical(features, model_dir=Path(args.model_dir))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
