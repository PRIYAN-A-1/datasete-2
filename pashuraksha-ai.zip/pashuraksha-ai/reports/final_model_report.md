# PashuRaksha AI — Final Model Performance Report
Generated: 2026-09-15T14:09:22.196986
Random seed: 42

---
## Dataset
**No datasets were discovered in the project.**

Per spec §58 (CRITICAL RULE — DO NOT FAKE ANYTHING), training could not be completed because the required dataset is not available. The pipeline has been fully implemented and is runnable once real data is placed under `data/images/<class>/` or `data/clinical/<file>.csv`.

---
## Image Model (MobileNetV3)
Image model was **not trained** — no image data was available (spec §58).

---
## Clinical Model (XGBoost)
Clinical model was **not trained** — no clinical data was available (spec §58).

---
## Anomaly Detector
No anomaly detector trained — required image model or clinical data was missing.

---
## Limitations
- **Dataset size**: This prototype depends on whatever real data is available in `data/images/` and `data/clinical/`. With small datasets, reported metrics have wide confidence intervals and should not be interpreted as production-ready.
- **Class imbalance**: When disease classes are heavily imbalanced, the macro F1 may be substantially lower than accuracy. Class-weighted losses and WeightedRandomSampler are used to mitigate, but cannot compensate for missing classes entirely.
- **Geographic / breed diversity**: Without explicit latitude/longitude/breed columns, the model cannot generalize across regions or breeds outside the training distribution.
- **Image quality**: Augmentations are designed to be biologically reasonable, but very low-quality images (blur, poor lighting, occlusion) can still produce false negatives.
- **Unseen diseases**: The anomaly detector can flag inputs as 'Unknown Pattern', but it cannot identify which specific disease an unseen sample represents.
- **Lack of laboratory labels**: All predictions are screening signals, not confirmed diagnoses. Veterinary/laboratory confirmation is required for clinical decisions.

---
## Status Summary
> **Pipeline implemented. Models NOT trained — no data available.**
