"""SHAP-based clinical explainability (spec §30).

Generates:
  - global SHAP feature importance (bar plot + JSON)
  - local prediction explanation (force plot for a single sample)

Usage:
    python explainability/clinical_explain.py --data data/clinical/clinical.csv
    python explainability/clinical_explain.py --data data/clinical/clinical.csv --row-index 0
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402

log = get_logger("clinical_explain")


def _format_contributing_factors(shap_values, feature_names, base_value, prediction_value, top_k=5):
    """Format SHAP values as a sorted list of (feature, contribution) pairs."""
    import numpy as np
    if isinstance(shap_values, list):
        # multiclass: use the class with max prediction
        shap_arr = shap_values[int(np.argmax(prediction_value))]
    else:
        shap_arr = shap_values
    if shap_arr.ndim == 2:
        shap_arr = shap_arr[0]
    contributions = list(zip(feature_names, shap_arr.tolist()))
    contributions.sort(key=lambda kv: abs(kv[1]), reverse=True)
    return contributions[:top_k]


def explain_clinical(
    data_path: Path,
    row_index: int | None = None,
    model_dir: Path | None = None,
    reports_dir: Path | None = None,
    background_samples: int = 100,
    seed: int = 42,
):
    import joblib
    import numpy as np
    from utils.seed import set_global_seed
    set_global_seed(seed)

    if model_dir is None:
        model_dir = PROJECT_ROOT / "models" / "clinical_model"
    if reports_dir is None:
        reports_dir = PROJECT_ROOT / "reports" / "explanations" / "clinical"
    reports_dir.mkdir(parents=True, exist_ok=True)

    model = joblib.load(model_dir / "model.joblib")
    pre = joblib.load(model_dir / "preprocessor.joblib")
    sym_enc = joblib.load(model_dir / "symptom_encoder.joblib")
    le = joblib.load(model_dir / "label_encoder.joblib")
    groups = joblib.load(model_dir / "feature_groups.joblib")

    # Rebuild split deterministically
    from data_processing.prepare_clinical import prepare_clinical
    prepared = prepare_clinical(data_path, model_dir, seed=seed)
    X_train = prepared["X_train"]
    X_test = prepared["X_test"]
    feature_names = prepared["feature_names"]

    # SHAP explainer
    try:
        import shap
    except ImportError as e:
        raise SystemExit("shap is required. Install with `pip install shap`.") from e

    # Background: subsample training set for KernelExplainer efficiency
    bg_n = min(background_samples, X_train.shape[0])
    rng = np.random.RandomState(seed)
    bg_idx = rng.choice(X_train.shape[0], size=bg_n, replace=False)
    background = X_train[bg_idx]

    # TreeExplainer is much faster for XGBoost
    try:
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test)
    except Exception as e:  # noqa: BLE001
        log.warning("TreeExplainer failed (%s) — falling back to KernelExplainer.", e)
        explainer = shap.KernelExplainer(model.predict_proba, background)
        shap_values = explainer.shap_values(X_test[:50])

    # Global importance: mean(|SHAP|) per feature
    if isinstance(shap_values, list):
        global_importance = np.mean(
            [np.abs(sv).mean(axis=0) for sv in shap_values], axis=0,
        )
    else:
        sv = np.array(shap_values)
        if sv.ndim == 3:
            global_importance = np.abs(sv).mean(axis=(0, 2))
        else:
            global_importance = np.abs(sv).mean(axis=0)

    global_pairs = sorted(
        zip(feature_names, global_importance.tolist()),
        key=lambda kv: kv[1], reverse=True,
    )

    # Save global importance bar plot
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        top = global_pairs[:15]
        fig, ax = plt.subplots(figsize=(8, 6), constrained_layout=True)
        ax.barh([k for k, _ in top][::-1], [v for _, v in top][::-1])
        ax.set_xlabel("mean(|SHAP value|)")
        ax.set_title("Global SHAP feature importance")
        fig.savefig(reports_dir / "shap_global_importance.png", dpi=120)
        plt.close(fig)
    except ImportError:
        pass

    # Local explanation for a single row (spec §30 — Contributing Factors list)
    local_pairs = None
    if row_index is not None and row_index < X_test.shape[0]:
        row = X_test[row_index:row_index + 1]
        pred_proba = model.predict_proba(row)[0]
        if isinstance(shap_values, list):
            local_sv = [sv[row_index] for sv in shap_values]
        else:
            local_sv = shap_values[row_index]
        local_pairs = _format_contributing_factors(
            local_sv, feature_names, base_value=None,
            prediction_value=pred_proba, top_k=10,
        )

    return {
        "global_importance": [{"feature": k, "mean_abs_shap": v} for k, v in global_pairs],
        "local_row_index": row_index,
        "local_contributing_factors": (
            [{"feature": k, "contribution": v} for k, v in local_pairs] if local_pairs else None
        ),
        "n_classes": len(le.classes_),
        "label_classes": list(le.classes_),
        "note": "Contributing factors use SHAP values. Say 'associated with', not 'caused by'.",
        "reports_dir": str(reports_dir),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Clinical SHAP explainability (spec §30).")
    parser.add_argument("--data", required=True, type=str)
    parser.add_argument("--row-index", type=int, default=None)
    parser.add_argument("--model-dir", type=str, default="models/clinical_model")
    parser.add_argument("--reports-dir", type=str, default="reports/explanations/clinical")
    args = parser.parse_args(argv)
    result = explain_clinical(
        data_path=Path(args.data),
        row_index=args.row_index,
        model_dir=Path(args.model_dir),
        reports_dir=Path(args.reports_dir),
    )
    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
