"""Grad-CAM-style image explainability (spec §29).

Generates a heatmap showing model attention/influence over an input image.
The heatmap does NOT prove that a highlighted lesion is medically responsible
for the disease — it only shows which regions the model attended to.

Usage:
    python explainability/image_explain.py --image sample.jpg --out reports/explanations/images/
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.device import get_device  # noqa: E402
from utils.logger import get_logger  # noqa: E402

log = get_logger("image_explain")


class GradCAM:
    """Minimal Grad-CAM implementation for MobileNetV3.

    Hooks the last convolutional layer of MobileNetV3 features to capture
    forward activations and backward gradients w.r.t. the predicted class.
    """

    def __init__(self, model, target_layer):
        import torch
        self.model = model
        self.target_layer = target_layer
        self.activations = None
        self.gradients = None
        self._fwd_hook = target_layer.register_forward_hook(self._save_activation)
        self._bwd_hook = target_layer.register_full_backward_hook(self._save_gradient)

    def _save_activation(self, module, inp, out):
        self.activations = out

    def _save_gradient(self, module, grad_in, grad_out):
        self.gradients = grad_out[0]

    def __call__(self, x, class_idx=None):
        import torch
        logits = self.model(x)
        if class_idx is None:
            class_idx = int(logits.argmax(dim=1).item())
        self.model.zero_grad()
        logits[0, class_idx].backward(retain_graph=False)
        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1, keepdim=True)
        cam = torch.relu(cam)
        cam = cam - cam.min()
        if cam.max() > 0:
            cam = cam / cam.max()
        return cam.detach().cpu().numpy()[0, 0], class_idx

    def remove_hooks(self):
        self._fwd_hook.remove()
        self._bwd_hook.remove()


def find_last_conv_layer(model):
    """Return the last Conv2d layer of the MobileNetV3 features block."""
    import torch.nn as nn
    last_conv = None
    for module in model.features.modules():
        if isinstance(module, nn.Conv2d):
            last_conv = module
    if last_conv is None:
        raise RuntimeError("Could not find any Conv2d layer in model.features.")
    return last_conv


def explain_image(
    image_path: Path,
    model_path: Path | None = None,
    out_dir: Path | None = None,
    device_pref: str = "auto",
):
    import numpy as np
    import torch
    import yaml
    from PIL import Image

    if model_path is None:
        model_path = PROJECT_ROOT / "models" / "image_model" / "best_model.pth"
    if out_dir is None:
        out_dir = PROJECT_ROOT / "reports" / "explanations" / "images"
    out_dir.mkdir(parents=True, exist_ok=True)

    if not model_path.exists():
        raise FileNotFoundError(f"Model not found: {model_path}")

    device = get_device(device_pref, verbose=False)
    payload = torch.load(model_path, map_location=device, weights_only=False)
    class_names = payload["class_names"]
    n_classes = len(class_names)

    from torchvision import models
    model = models.mobilenet_v3_large(weights=None)
    in_features = model.classifier[-1].in_features
    model.classifier[-1] = torch.nn.Linear(in_features, n_classes)
    model.load_state_dict(payload["model_state_dict"])
    model.to(device).eval()

    target_layer = find_last_conv_layer(model)
    grad_cam = GradCAM(model, target_layer)

    # Preprocess
    with open(PROJECT_ROOT / "configs" / "default.yaml", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    from data_processing.prepare_images import build_inference_transform
    tf = build_inference_transform(cfg)
    img_pil = Image.open(image_path).convert("RGB")
    img_tensor = tf(img_pil).unsqueeze(0).to(device)
    img_tensor.requires_grad_(True)

    # Generate heatmap
    cam, class_idx = grad_cam(img_tensor)
    grad_cam.remove_hooks()

    # Overlay
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        log.warning("matplotlib unavailable — skipping heatmap overlay plot.")
        return None

    cam_resized = np.array(Image.fromarray((cam * 255).astype("uint8")).resize(img_pil.size))
    fig, ax = plt.subplots(figsize=(7, 7), constrained_layout=True)
    ax.imshow(img_pil)
    ax.imshow(cam_resized, cmap="jet", alpha=0.45)
    ax.set_title(f"Grad-CAM attention — predicted: {class_names[class_idx]}")
    ax.axis("off")
    out_path = out_dir / f"gradcam_{Path(image_path).stem}.png"
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    log.info("Saved Grad-CAM heatmap to %s", out_path)

    metadata = {
        "image": str(image_path),
        "predicted_class": class_names[class_idx],
        "class_index": int(class_idx),
        "heatmap_path": str(out_path),
        "explanation_note": (
            "Heatmap shows model attention/influence. It does NOT prove that a "
            "highlighted lesion is medically responsible for the disease."
        ),
    }
    with open(out_dir / f"gradcam_{Path(image_path).stem}.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    return metadata


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Image explainability via Grad-CAM (spec §29).")
    parser.add_argument("--image", required=True, type=str)
    parser.add_argument("--model", type=str, default="models/image_model/best_model.pth")
    parser.add_argument("--out", type=str, default="reports/explanations/images")
    args = parser.parse_args(argv)
    meta = explain_image(Path(args.image), Path(args.model), Path(args.out))
    print(json.dumps(meta or {}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
