"""Clinical/tabular preprocessing (spec §16).

- Numerical features: median imputation + StandardScaler
- Categorical features: most-frequent imputation + OneHotEncoder
- Multi-value symptom columns (e.g. "fever,cough,loss_of_appetite"):
  MultiLabelBinarizer-style encoding into per-symptom binary columns
- Target column is auto-detected (see inspect_dataset._detect_target_column)
- Saves a fitted preprocessor (joblib) for reuse during inference

Spec §56 (Data Leakage Protection): preprocessing is fit ONLY on training data.

Usage:
    python data_processing/prepare_clinical.py --data data/clinical/clinical.csv
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402
from utils.seed import set_global_seed  # noqa: E402

log = get_logger("prepare_clinical")


# Heuristic feature-group detection -----------------------------------------
ID_SUFFIXES = ("_id", "_uuid", "_guid", "_identifier")
ID_EXACT = {"id", "uuid", "guid", "identifier", "animalid", "farmid", "caseid"}
ID_PREFIXES = ("animal_id", "farm_id", "patient_id", "owner_id", "vet_id",
               "record_id", "submission_id", "case_id")


def _is_id_like(col: str) -> bool:
    """Return True if `col` looks like an identifier column that should be
    excluded from features to avoid target leakage (spec §56)."""
    name = col.lower().strip()
    if name in ID_EXACT:
        return True
    if any(name.endswith(s) for s in ID_SUFFIXES):
        return True
    return any(name.startswith(p) for p in ID_PREFIXES)


def detect_feature_groups(df, target_col: str | None = None):
    """Split df columns into numerical / categorical / multivalue / target groups.

    ID-like columns (animal_id, farm_id, etc.) are excluded to prevent leakage
    (spec §56).
    """
    numeric, categorical, multivalue, excluded_ids = [], [], [], []
    for col in df.columns:
        if col == target_col:
            continue
        if _is_id_like(col):
            excluded_ids.append(col)
            continue
        s = df[col].dropna()
        if s.empty:
            categorical.append(col)
            continue
        # Multi-value heuristic: strings containing comma/semicolon
        if s.dtype == object:
            sample = s.astype(str).head(50)
            multi = sample.str.contains(r"[,;|]").sum()
            if multi > len(sample) * 0.3:
                multivalue.append(col)
                continue
            # Otherwise categorical
            categorical.append(col)
        elif str(s.dtype).startswith(("int", "float")):
            # Skip if cardinality == number of rows (looks like an ID even without the name match)
            if s.nunique() == len(s) and len(s) > 10:
                excluded_ids.append(col)
                continue
            numeric.append(col)
        else:
            categorical.append(col)
    return {
        "numeric": numeric,
        "categorical": categorical,
        "multivalue": multivalue,
        "excluded_ids": excluded_ids,
        "target": target_col,
    }


def build_preprocessor(groups: dict):
    """Build a ColumnTransformer-style preprocessor.

    Returns a scikit-learn Pipeline-wrapped ColumnTransformer that yields a
    dense array ( csr is fine too ).
    """
    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler

    numeric_steps = [
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ]
    categorical_steps = [
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ]

    transformers = []
    if groups["numeric"]:
        transformers.append(("numeric", Pipeline(numeric_steps), groups["numeric"]))
    if groups["categorical"]:
        transformers.append(("categorical", Pipeline(categorical_steps), groups["categorical"]))
    # Multi-value columns: handled separately via MultiSymptomEncoder (see below).
    pre = ColumnTransformer(transformers=transformers, remainder="drop")
    return pre


class MultiSymptomEncoder:
    """Fit-transform a list of multi-value string columns into binary columns.

    Each value like "fever,cough,loss_of_appetite" becomes one binary column
    per symptom (spec §16 — MultiLabelBinarizer approach).
    """

    def __init__(self):
        self.symptoms_per_col_: dict[str, list[str]] = {}

    def fit(self, df, cols: list[str]) -> "MultiSymptomEncoder":
        import pandas as pd

        self.symptoms_per_col_ = {}
        for col in cols:
            s = df[col].dropna().astype(str)
            symptoms = set()
            for v in s:
                for tok in v.replace(";", ",").replace("|", ",").split(","):
                    tok = tok.strip().lower()
                    if tok:
                        symptoms.add(tok)
            self.symptoms_per_col_[col] = sorted(symptoms)
        return self

    def transform(self, df) -> "pd.DataFrame":
        import pandas as pd

        out = pd.DataFrame(index=df.index)
        for col, symptoms in self.symptoms_per_col_.items():
            s = df[col].fillna("").astype(str)
            for sym in symptoms:
                out[f"{col}__{sym}"] = s.apply(
                    lambda v, sym=sym: int(sym in [t.strip().lower() for t in v.replace(";", ",").replace("|", ",").split(",")])
                )
        return out

    def get_feature_names_out(self):
        names = []
        for col, symptoms in self.symptoms_per_col_.items():
            names.extend(f"{col}__{s}" for s in symptoms)
        return names


def prepare_clinical(data_path: Path, out_dir: Path, seed: int = 42):
    """Top-level preprocessing entrypoint.

    Returns dict containing the fitted components and the train/val/test matrices.
    """
    set_global_seed(seed)
    try:
        import pandas as pd
    except ImportError as e:
        raise SystemExit("pandas is required.") from e

    ext = data_path.suffix.lower()
    if ext == ".csv":
        df = pd.read_csv(data_path)
    elif ext == ".xlsx":
        df = pd.read_excel(data_path)
    elif ext == ".parquet":
        df = pd.read_parquet(data_path)
    elif ext == ".json":
        try:
            df = pd.read_json(data_path)
        except ValueError:
            df = pd.read_json(data_path, lines=True)
    else:
        raise ValueError(f"Unsupported extension: {ext}")

    # Detect target
    from data_processing.inspect_dataset import _detect_target_column
    target_col = _detect_target_column(df)
    if target_col is None:
        raise ValueError("No target column could be detected for clinical dataset.")

    groups = detect_feature_groups(df, target_col=target_col)
    log.info("Clinical feature groups: %s", groups)

    # Stratified split — fit preprocessing ONLY on training portion (spec §56)
    from sklearn.model_selection import train_test_split
    y = df[target_col].astype(str)
    X = df.drop(columns=[target_col])

    X_trainval, X_test, y_trainval, y_test = train_test_split(
        X, y, test_size=0.15, random_state=seed, stratify=y if y.nunique() <= 30 else None
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_trainval, y_trainval, test_size=0.1765, random_state=seed,
        stratify=y_trainval if y_trainval.nunique() <= 30 else None,
    )

    # Fit preprocessors on TRAIN only
    pre = build_preprocessor(groups)
    pre.fit(X_train)
    sym_enc = MultiSymptomEncoder()
    if groups["multivalue"]:
        sym_enc.fit(X_train, groups["multivalue"])

    def transform_block(X_block):
        import numpy as np
        import pandas as pd
        main_features = pre.transform(X_block)
        if groups["multivalue"]:
            sym_df = sym_enc.transform(X_block)
            sym_arr = sym_df.values
            combined = np.hstack([main_features, sym_arr])
            cols = list(pre.get_feature_names_out()) + list(sym_enc.get_feature_names_out())
        else:
            combined = main_features
            cols = list(pre.get_feature_names_out())
        return combined, cols

    Xtr, feat_names = transform_block(X_train)
    Xva, _ = transform_block(X_val)
    Xte, _ = transform_block(X_test)

    # Encode labels
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    y_train_enc = le.fit_transform(y_train)
    y_val_enc = le.transform(y_val)
    y_test_enc = le.transform(y_test)

    # Persist artifacts
    import joblib
    out_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(pre, out_dir / "preprocessor.joblib")
    joblib.dump(sym_enc, out_dir / "symptom_encoder.joblib")
    joblib.dump(le, out_dir / "label_encoder.joblib")
    joblib.dump(groups, out_dir / "feature_groups.joblib")

    return {
        "X_train": Xtr,
        "X_val": Xva,
        "X_test": Xte,
        "y_train": y_train_enc,
        "y_val": y_val_enc,
        "y_test": y_test_enc,
        "feature_names": feat_names,
        "label_classes": list(le.classes_),
        "groups": groups,
        "target_col": target_col,
        "preprocessor_path": str(out_dir / "preprocessor.joblib"),
        "symptom_encoder_path": str(out_dir / "symptom_encoder.joblib"),
        "label_encoder_path": str(out_dir / "label_encoder.joblib"),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Prepare clinical/tabular data (spec §16).")
    parser.add_argument("--data", required=True, type=str)
    parser.add_argument("--out-dir", type=str, default="models/clinical_model")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args(argv)

    out_dir = Path(args.out_dir)
    result = prepare_clinical(Path(args.data), out_dir, seed=args.seed)

    # Save a small JSON summary (no arrays)
    summary = {
        "target_col": result["target_col"],
        "n_train": int(len(result["y_train"])),
        "n_val": int(len(result["y_val"])),
        "n_test": int(len(result["y_test"])),
        "n_features": int(result["X_train"].shape[1]),
        "label_classes": result["label_classes"],
        "feature_groups": result["groups"],
        "preprocessor_path": result["preprocessor_path"],
        "symptom_encoder_path": result["symptom_encoder_path"],
        "label_encoder_path": result["label_encoder_path"],
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "preprocessing_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)
    print(json.dumps(summary, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
