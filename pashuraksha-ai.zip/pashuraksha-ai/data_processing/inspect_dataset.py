"""Dataset inspection (spec §3, §15).

Inspects image and clinical/tabular datasets automatically. Searches a list of
candidate directories. Reports real statistics only — never invents numbers
(spec §58).

Usage:
    python data_processing/inspect_dataset.py --data-dir data/images
    python data_processing/inspect_dataset.py --clinical data/clinical/clinical.csv
    python data_processing/inspect_dataset.py --all
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Iterable

import yaml

# Make the project root importable when run as `python data_processing/inspect_dataset.py`
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402

log = get_logger("inspect")

PROJECT_ROOT_CANON = Path(__file__).resolve().parents[1]
CONFIG_PATH = PROJECT_ROOT_CANON / "configs" / "default.yaml"
REPORTS_DIR = PROJECT_ROOT_CANON / "reports"
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
CLINICAL_EXTS = {".csv", ".xlsx", ".json", ".parquet"}


def load_config() -> dict:
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

def resolve_search_roots(config: dict, kind: str) -> list[Path]:
    """Return existing candidate directories to search for `kind` data."""
    if kind == "image":
        keys = ["image_search_dirs"]
    elif kind == "clinical":
        keys = ["clinical_search_dirs"]
    else:
        keys = []
    candidates: list[Path] = []
    data_cfg = config.get("data", {})
    for k in keys:
        for rel in data_cfg.get(k, []) or []:
            p = (PROJECT_ROOT_CANON / rel).resolve()
            if p.exists() and p.is_dir():
                candidates.append(p)
    # Always also probe a couple of generic locations
    for generic in ["data", "dataset", "datasets"]:
        p = (PROJECT_ROOT_CANON / generic).resolve()
        if p.exists() and p.is_dir():
            candidates.append(p)
    # Deduplicate while preserving order
    seen, out = set(), []
    for p in candidates:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out


def discover_image_datasets(config: dict) -> list[Path]:
    """Find directories containing image-class subfolders."""
    roots = resolve_search_roots(config, "image")
    found: list[Path] = []
    for root in roots:
        # Two layouts supported:
        #   root/<class>/<image>.jpg           (root itself is the dataset)
        #   root/<dataset_name>/<class>/<img>  (each subdir is a separate dataset)
        subdirs = [d for d in root.iterdir() if d.is_dir() and not d.name.startswith(".")]
        has_images_directly = any(
            f.suffix.lower() in IMAGE_EXTS for f in root.iterdir() if f.is_file()
        )
        if has_images_directly or _looks_like_image_dataset(root):
            found.append(root)
        for d in subdirs:
            if _looks_like_image_dataset(d):
                # Treat nested dataset dir as a candidate
                found.append(d)
    # Deduplicate
    seen, out = set(), []
    for p in found:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out


def _looks_like_image_dataset(path: Path) -> bool:
    """Return True if `path` contains at least one subdirectory with image files."""
    try:
        for d in path.iterdir():
            if d.is_dir() and any(
                f.suffix.lower() in IMAGE_EXTS for f in d.iterdir() if f.is_file()
            ):
                return True
    except (PermissionError, OSError):
        pass
    return False


def discover_clinical_datasets(config: dict) -> list[Path]:
    """Find clinical/tabular data files (CSV/XLSX/JSON/Parquet).

    Deduplicates against resolved paths so that nested search roots do not
    surface the same file multiple times.
    """
    roots = resolve_search_roots(config, "clinical")
    found: list[Path] = []
    seen: set[Path] = set()
    for root in roots:
        for f in root.rglob("*"):
            if f.is_file() and f.suffix.lower() in CLINICAL_EXTS:
                rp = f.resolve()
                if rp not in seen:
                    seen.add(rp)
                    found.append(f)
    return found


# ---------------------------------------------------------------------------
# Image inspection
# ---------------------------------------------------------------------------

def _file_md5(path: Path, chunk: int = 1 << 16) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def inspect_image_dataset(dataset_dir: Path, report_dir: Path | None = None) -> dict:
    """Inspect a single image dataset directory and return a stats dict."""
    log.info("Inspecting image dataset: %s", dataset_dir)
    class_dirs = sorted(
        [d for d in dataset_dir.iterdir() if d.is_dir() and not d.name.startswith(".")]
    )
    if not class_dirs:
        log.warning("No class subdirectories found in %s", dataset_dir)
    per_class: dict[str, dict] = {}
    total_valid = 0
    corrupted: list[str] = []
    unreadable: list[str] = []
    zero_byte: list[str] = []
    unsupported: list[str] = []
    image_formats: Counter = Counter()
    resolutions: list[tuple[int, int]] = []
    md5_seen: dict[str, str] = {}     # md5 -> first path
    duplicates: list[dict] = []

    try:
        from PIL import Image, UnidentifiedImageError
    except ImportError as e:
        raise SystemExit("Pillow is required for image inspection. Install with `pip install Pillow`.") from e

    for cls_dir in class_dirs:
        files = [f for f in cls_dir.iterdir() if f.is_file()]
        n_valid = 0
        for f in files:
            ext = f.suffix.lower()
            if ext not in IMAGE_EXTS:
                unsupported.append(str(f))
                continue
            try:
                if f.stat().st_size == 0:
                    zero_byte.append(str(f))
                    continue
                with Image.open(f) as img:
                    img.verify()  # only verifies, doesn't decode
                # Re-open to fetch size (verify() leaves file unusable)
                with Image.open(f) as img:
                    w, h = img.size
                    fmt = (img.format or ext.lstrip(".")).upper()
                    image_formats[fmt] += 1
                    resolutions.append((w, h))
                md5 = _file_md5(f)
                if md5 in md5_seen:
                    duplicates.append({"file": str(f), "duplicate_of": md5_seen[md5]})
                else:
                    md5_seen[md5] = str(f)
                n_valid += 1
                total_valid += 1
            except (UnidentifiedImageError, OSError, ValueError) as e:
                corrupted.append({"file": str(f), "error": type(e).__name__})
        per_class[cls_dir.name] = {
            "n_images": n_valid,
            "n_files_total": len(files),
        }

    n_classes = len(per_class)
    counts = [v["n_images"] for v in per_class.values()]
    min_n = min(counts) if counts else 0
    max_n = max(counts) if counts else 0
    imbalance_ratio = (max_n / min_n) if min_n > 0 else float("inf") if max_n > 0 else 0.0

    # Resolution stats
    if resolutions:
        widths = [r[0] for r in resolutions]
        heights = [r[1] for r in resolutions]
        res_stats = {
            "min_width": min(widths),
            "max_width": max(widths),
            "min_height": min(heights),
            "max_height": max(heights),
            "mean_width": float(sum(widths) / len(widths)),
            "mean_height": float(sum(heights) / len(heights)),
            "unique_resolutions": len(set(resolutions)),
        }
    else:
        res_stats = {}

    report = {
        "dataset_dir": str(dataset_dir),
        "total_valid_images": total_valid,
        "n_classes": n_classes,
        "class_names": list(per_class.keys()),
        "per_class": per_class,
        "min_samples_per_class": min_n,
        "max_samples_per_class": max_n,
        "class_imbalance_ratio": imbalance_ratio,
        "image_formats": dict(image_formats),
        "resolution_stats": res_stats,
        "corrupted_images": corrupted,
        "n_corrupted": len(corrupted),
        "unreadable_images": unreadable,
        "n_unreadable": len(unreadable),
        "zero_byte_files": zero_byte,
        "n_zero_byte": len(zero_byte),
        "unsupported_files": unsupported,
        "n_unsupported": len(unsupported),
        "duplicate_images": duplicates,
        "n_duplicates": len(duplicates),
    }

    if report_dir:
        _write_image_reports(report, report_dir, dataset_dir.name)
    return report


def _write_image_reports(report: dict, report_dir: Path, dataset_name: str) -> None:
    report_dir.mkdir(parents=True, exist_ok=True)
    safe_name = dataset_name.replace("/", "_")
    # JSON report
    with open(report_dir / f"dataset_report_{safe_name}.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    # CSVs for corrupted / duplicates
    import csv

    with open(report_dir / f"corrupted_images_{safe_name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file", "error"])
        for c in report["corrupted_images"]:
            w.writerow([c["file"], c["error"]])
    with open(report_dir / f"duplicate_images_{safe_name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file", "duplicate_of"])
        for d in report["duplicate_images"]:
            w.writerow([d["file"], d["duplicate_of"]])
    # Class distribution plot (matplotlib optional)
    _plot_class_distribution(report, report_dir, safe_name)


def _plot_class_distribution(report: dict, report_dir: Path, safe_name: str) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        log.warning("matplotlib not installed; skipping class-distribution plot.")
        return
    per_class = report.get("per_class", {})
    if not per_class:
        return
    classes = list(per_class.keys())
    counts = [per_class[c]["n_images"] for c in classes]
    fig, ax = plt.subplots(figsize=(max(8, len(classes) * 0.5), 5), constrained_layout=True)
    ax.bar(classes, counts)
    ax.set_xlabel("Class")
    ax.set_ylabel("Number of images")
    ax.set_title(f"Class distribution — {safe_name}")
    if len(classes) > 8:
        ax.tick_params(axis="x", labelrotation=45)
    out = report_dir / f"class_distribution_{safe_name}.png"
    fig.savefig(out, dpi=120)
    plt.close(fig)
    log.info("Class distribution plot saved to %s", out)


# ---------------------------------------------------------------------------
# Clinical inspection
# ---------------------------------------------------------------------------

def inspect_clinical_file(path: Path, report_dir: Path | None = None) -> dict:
    """Inspect a single clinical tabular file and return a stats dict."""
    log.info("Inspecting clinical file: %s", path)
    try:
        import pandas as pd
    except ImportError as e:
        raise SystemExit("pandas is required for clinical inspection.") from e

    ext = path.suffix.lower()
    if ext == ".csv":
        df = pd.read_csv(path)
    elif ext == ".xlsx":
        df = pd.read_excel(path)
    elif ext == ".parquet":
        df = pd.read_parquet(path)
    elif ext == ".json":
        try:
            df = pd.read_json(path)
        except ValueError:
            # Could be a JSON-lines file
            df = pd.read_json(path, lines=True)
    else:
        raise ValueError(f"Unsupported clinical extension: {ext}")

    n_rows, n_cols = df.shape
    dtypes = {c: str(df[c].dtype) for c in df.columns}
    missing = {c: int(df[c].isna().sum()) for c in df.columns}
    n_duplicates = int(df.duplicated().sum())

    # Unique counts for categorical-ish columns
    n_unique = {}
    for c in df.columns:
        try:
            n_unique[c] = int(df[c].nunique(dropna=True))
        except TypeError:
            n_unique[c] = -1

    # Attempt to detect target column (last column heuristic + name hints)
    target_col = _detect_target_column(df)

    target_dist: dict = {}
    problem_type = "unknown"
    if target_col is not None:
        s = df[target_col].dropna()
        vc = s.value_counts().to_dict()
        target_dist = {str(k): int(v) for k, v in vc.items()}
        n_classes = len(target_dist)
        problem_type = "binary" if n_classes == 2 else "multiclass" if n_classes <= 30 else "regression"
        log.info(
            "Detected target column: '%s' (%s, %d classes)",
            target_col, problem_type, n_classes,
        )

    imbalance_ratio = 0.0
    if target_dist:
        counts = list(target_dist.values())
        imb_max = max(counts)
        imb_min = min(counts)
        imbalance_ratio = (imb_max / imb_min) if imb_min > 0 else float("inf")

    report = {
        "file": str(path),
        "n_rows": int(n_rows),
        "n_columns": int(n_cols),
        "columns": list(df.columns),
        "dtypes": dtypes,
        "missing_values": missing,
        "n_duplicate_rows": n_duplicates,
        "n_unique_values": n_unique,
        "target_column": target_col,
        "problem_type": problem_type,
        "target_distribution": target_dist,
        "class_imbalance_ratio": imbalance_ratio,
    }

    if report_dir:
        report_dir.mkdir(parents=True, exist_ok=True)
        safe = path.stem.replace("/", "_")
        with open(report_dir / f"clinical_report_{safe}.json", "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)

    return report


def _detect_target_column(df) -> str | None:
    """Heuristic for detecting the disease/health target column."""
    candidates = ["disease", "label", "target", "diagnosis", "condition",
                  "health_status", "disease_label", "risk", "class", "outcome"]
    for c in candidates:
        for col in df.columns:
            if col.lower() == c:
                return col
    for c in candidates:
        for col in df.columns:
            if c in col.lower():
                return col
    # Fall back to the last column
    return df.columns[-1] if len(df.columns) > 0 else None


# ---------------------------------------------------------------------------
# Top-level inspection
# ---------------------------------------------------------------------------

def inspect_all(config: dict, report_dir: Path | None = None) -> dict:
    """Inspect every discoverable dataset and return a combined report."""
    if report_dir is None:
        report_dir = REPORTS_DIR
    report_dir.mkdir(parents=True, exist_ok=True)

    image_datasets = discover_image_datasets(config)
    clinical_files = discover_clinical_datasets(config)

    log.info("Discovered %d image dataset(s) and %d clinical file(s).",
             len(image_datasets), len(clinical_files))

    image_reports = [inspect_image_dataset(d, report_dir) for d in image_datasets]
    clinical_reports = [inspect_clinical_file(f, report_dir) for f in clinical_files]

    combined = {
        "image_datasets": image_reports,
        "clinical_files": clinical_reports,
        "image_dataset_dirs": [str(p) for p in image_datasets],
        "clinical_files_list": [str(p) for p in clinical_files],
        "any_data_available": bool(image_reports or clinical_reports),
    }
    with open(report_dir / "dataset_report.json", "w", encoding="utf-8") as f:
        json.dump(combined, f, indent=2)
    return combined


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Inspect PashuRaksha datasets.")
    parser.add_argument("--data-dir", type=str, default=None,
                        help="Specific image dataset directory to inspect.")
    parser.add_argument("--clinical", type=str, default=None,
                        help="Specific clinical file to inspect.")
    parser.add_argument("--all", action="store_true",
                        help="Auto-discover and inspect all datasets.")
    parser.add_argument("--report-dir", type=str, default=None,
                        help="Directory to write reports into (default: reports/).")
    args = parser.parse_args(argv)

    config = load_config()
    report_dir = Path(args.report_dir) if args.report_dir else REPORTS_DIR
    report_dir.mkdir(parents=True, exist_ok=True)

    if args.all or (not args.data_dir and not args.clinical):
        combined = inspect_all(config, report_dir)
        if not combined["any_data_available"]:
            print("\n" + "=" * 72)
            print("NO DATASETS FOUND.")
            print("-" * 72)
            print("Searched the following candidate locations:")
            for d in resolve_search_roots(config, "image"):
                print(f"  images:    {d}")
            for d in resolve_search_roots(config, "clinical"):
                print(f"  clinical:  {d}")
            print("-" * 72)
            print("Per spec §58 (CRITICAL RULE — DO NOT FAKE ANYTHING):")
            print("  Training cannot be completed because the required dataset is not available.")
            print("  The pipeline has been implemented and is fully runnable once real data is")
            print("  placed under data/images/<class>/ or data/clinical/<file>.csv.")
            print("=" * 72 + "\n")
        else:
            print(json.dumps({
                "image_datasets": len(combined["image_datasets"]),
                "clinical_files": len(combined["clinical_files"]),
                "report": str(report_dir / "dataset_report.json"),
            }, indent=2))
        return 0

    if args.data_dir:
        report = inspect_image_dataset(Path(args.data_dir), report_dir)
        print(json.dumps(report, indent=2, default=str))
    if args.clinical:
        report = inspect_clinical_file(Path(args.clinical), report_dir)
        print(json.dumps(report, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
