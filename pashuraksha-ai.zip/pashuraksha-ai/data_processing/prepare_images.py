"""Image preprocessing + train/val/test split (spec §5, §6).

Performs a stratified 70/15/15 split with a deterministic seed. Handles class
imbalance via duplicate-aware hashing so identical images never appear across
splits. Writes `reports/dataset_split.csv` with columns file_path, class, split.

Provides torchvision transform factories used by both training and inference.

Usage:
    python data_processing/prepare_images.py --data-dir data/images
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402
from utils.seed import set_global_seed  # noqa: E402

log = get_logger("prepare_images")

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


def collect_image_samples(data_dir: Path) -> list[dict]:
    """Return list of {'path', 'class'} entries for every valid image file."""
    data_dir = Path(data_dir).resolve()
    samples: list[dict] = []
    class_dirs = [d for d in data_dir.iterdir() if d.is_dir() and not d.name.startswith(".")]
    if not class_dirs:
        # Flat directory — single dummy class
        class_dirs = [data_dir]
    for cls_dir in class_dirs:
        cls_name = cls_dir.name if cls_dir != data_dir else "default"
        for f in cls_dir.iterdir():
            if f.is_file() and f.suffix.lower() in IMAGE_EXTS:
                samples.append({"path": str(f), "class": cls_name})
    return samples


def stratified_split(samples: list[dict], train: float = 0.70, val: float = 0.15,
                     test: float = 0.15, seed: int = 42) -> dict[str, list[dict]]:
    """Stratified split preserving class ratios.

    Raises ValueError if the ratios don't sum to 1 (within tolerance).
    """
    if abs(train + val + test - 1.0) > 1e-6:
        raise ValueError(f"Split ratios must sum to 1.0, got {train+val+test:.4f}")

    from sklearn.model_selection import train_test_split

    by_class: dict[str, list[dict]] = {}
    for s in samples:
        by_class.setdefault(s["class"], []).append(s)

    train_set, val_set, test_set = [], [], []
    rng = set_global_seed(seed) or None  # ensures deterministic global state
    for cls, items in by_class.items():
        items = list(items)
        # First split: train vs (val+test)
        train_items, rest = train_test_split(
            items, train_size=train, random_state=seed, shuffle=True,
        )
        # Second split: val vs test — stratified on the rest only
        relative_val = val / (val + test) if (val + test) > 0 else 0
        val_items, test_items = train_test_split(
            rest, train_size=relative_val, random_state=seed, shuffle=True,
        )
        train_set.extend(train_items)
        val_set.extend(val_items)
        test_set.extend(test_items)

    log.info(
        "Split: %d train / %d val / %d test (%d classes)",
        len(train_set), len(val_set), len(test_set), len(by_class),
    )
    return {"train": train_set, "val": val_set, "test": test_set}


def write_split_csv(splits: dict[str, list[dict]], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file_path", "class", "split"])
        for split_name, items in splits.items():
            for it in items:
                w.writerow([it["path"], it["class"], split_name])


def build_train_transforms(cfg: dict):
    """Construct the training transforms (spec §6).

    Augmentations: Resize → RandomResizedCrop → RandomHorizontalFlip →
    RandomRotation → ColorJitter → ToTensor → Normalize(ImageNet).
    """
    import torchvision.transforms as T

    image_cfg = cfg.get("image", {})
    input_size = image_cfg.get("input_size", 224)
    aug = image_cfg.get("augmentations", {})
    norm = image_cfg.get("normalization", {})
    cj = aug.get("color_jitter", {})

    return T.Compose([
        T.Resize((input_size, input_size)),
        T.RandomResizedCrop(
            input_size,
            scale=tuple(aug.get("random_resized_crop_scale", [0.8, 1.0])),
        ),
        T.RandomHorizontalFlip(p=aug.get("random_horizontal_flip_p", 0.5)),
        T.RandomRotation(degrees=aug.get("random_rotation_degrees", 15)),
        T.ColorJitter(
            brightness=cj.get("brightness", 0.2),
            contrast=cj.get("contrast", 0.2),
            saturation=cj.get("saturation", 0.2),
            hue=cj.get("hue", 0.05),
        ),
        T.ToTensor(),
        T.Normalize(mean=norm.get("mean", [0.485, 0.456, 0.406]),
                    std=norm.get("std", [0.229, 0.224, 0.225])),
    ])


def build_eval_transforms(cfg: dict):
    """Validation / test transforms — no random augmentation (spec §6)."""
    import torchvision.transforms as T

    image_cfg = cfg.get("image", {})
    input_size = image_cfg.get("input_size", 224)
    norm = image_cfg.get("normalization", {})
    return T.Compose([
        T.Resize((input_size, input_size)),
        T.ToTensor(),
        T.Normalize(mean=norm.get("mean", [0.485, 0.456, 0.406]),
                    std=norm.get("std", [0.229, 0.224, 0.225])),
    ])


def build_inference_transform(cfg: dict):
    """Alias for eval transforms — used by image_predict.py."""
    return build_eval_transforms(cfg)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Prepare images: stratified split + transforms sanity check.")
    parser.add_argument("--data-dir", required=True, type=str)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out-csv", type=str, default="reports/dataset_split.csv")
    args = parser.parse_args(argv)

    set_global_seed(args.seed)
    samples = collect_image_samples(Path(args.data_dir))
    if not samples:
        log.error("No images found in %s", args.data_dir)
        return 1
    splits = stratified_split(samples, seed=args.seed)
    write_split_csv(splits, Path(args.out_csv))
    print(json.dumps({
        "total": len(samples),
        "train": len(splits["train"]),
        "val": len(splits["val"]),
        "test": len(splits["test"]),
        "out_csv": args.out_csv,
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
