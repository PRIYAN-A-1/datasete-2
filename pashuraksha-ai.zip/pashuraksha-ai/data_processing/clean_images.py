"""Image data cleaning (spec §4).

Detects corrupted, unreadable, zero-byte, unsupported, and duplicate image files.
Uses cryptographic (MD5) hashes for exact-duplicate detection. Does NOT destroy
the original dataset — instead generates CSV/JSON reports and optionally copies
the cleaned set to data/processed/images/.

Usage:
    python data_processing/clean_images.py --data-dir data/images
    python data_processing/clean_images.py --data-dir data/images --copy-to data/processed/images
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402

log = get_logger("clean_images")

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


def _file_md5(path: Path, chunk: int = 1 << 16) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def clean_image_dataset(
    data_dir: Path,
    out_dir: Path | None = None,
    copy_clean: bool = False,
) -> dict:
    """Walk `data_dir` and identify problematic files.

    Returns a report dict. If `copy_clean=True` and `out_dir` is given, valid
    unique images are copied into `out_dir/<class>/<filename>` preserving the
    class-folder structure.
    """
    try:
        from PIL import Image, UnidentifiedImageError
    except ImportError as e:
        raise SystemExit("Pillow is required. Install with `pip install Pillow`.") from e

    data_dir = Path(data_dir).resolve()
    if not data_dir.exists():
        raise FileNotFoundError(f"Dataset directory not found: {data_dir}")

    corrupted: list[dict] = []
    unreadable: list[dict] = []
    zero_byte: list[str] = []
    unsupported: list[str] = []
    duplicates: list[dict] = []
    md5_seen: dict[str, str] = {}

    class_dirs = [d for d in data_dir.iterdir() if d.is_dir() and not d.name.startswith(".")]
    if not class_dirs:
        log.warning("No class subdirectories in %s", data_dir)
        class_dirs = [data_dir]

    n_valid = 0
    if copy_clean and out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)

    for cls_dir in class_dirs:
        for f in cls_dir.iterdir() if cls_dir is not data_dir else []:
            pass
        files = [f for f in cls_dir.iterdir() if f.is_file()]
        for f in files:
            ext = f.suffix.lower()
            if ext not in IMAGE_EXTS:
                unsupported.append(str(f))
                continue
            try:
                if f.stat().st_size == 0:
                    zero_byte.append(str(f))
                    continue
                with Image.open(f) as img:
                    img.verify()
                # verify leaves file unusable; reopen for decode check
                with Image.open(f) as img:
                    img.load()
                md5 = _file_md5(f)
                if md5 in md5_seen:
                    duplicates.append({"file": str(f), "duplicate_of": md5_seen[md5]})
                    continue
                md5_seen[md5] = str(f)
                n_valid += 1
                if copy_clean and out_dir:
                    dest_cls = out_dir / cls_dir.name
                    dest_cls.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, dest_cls / f.name)
            except (UnidentifiedImageError, OSError, ValueError) as e:
                corrupted.append({"file": str(f), "error": type(e).__name__})
            except Exception as e:  # noqa: BLE001
                unreadable.append({"file": str(f), "error": str(e)})

    report = {
        "source_dir": str(data_dir),
        "valid_unique_images": n_valid,
        "corrupted_images": corrupted,
        "n_corrupted": len(corrupted),
        "unreadable_images": unreadable,
        "n_unreadable": len(unreadable),
        "zero_byte_files": zero_byte,
        "n_zero_byte": len(zero_byte),
        "unsupported_files": unsupported,
        "n_unsupported": len(unsupported),
        "duplicate_images": duplicates,
        "n_duplicates": len(duplicates),
        "cleaned_copy_dir": str(out_dir) if (copy_clean and out_dir) else None,
    }
    return report


def write_cleaning_reports(report: dict, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "dataset_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    with open(out_dir / "corrupted_images.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file", "error"])
        for c in report["corrupted_images"]:
            w.writerow([c["file"], c["error"]])
    with open(out_dir / "duplicate_images.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file", "duplicate_of"])
        for d in report["duplicate_images"]:
            w.writerow([d["file"], d["duplicate_of"]])
    with open(out_dir / "zero_byte_files.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file"])
        for z in report["zero_byte_files"]:
            w.writerow([z])
    with open(out_dir / "unsupported_files.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["file"])
        for u in report["unsupported_files"]:
            w.writerow([u])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Clean an image dataset (spec §4).")
    parser.add_argument("--data-dir", required=True, type=str)
    parser.add_argument("--copy-to", type=str, default=None,
                        help="Optional destination dir for cleaned images.")
    parser.add_argument("--report-dir", type=str, default="reports")
    args = parser.parse_args(argv)

    copy_clean = bool(args.copy_to)
    out_dir = Path(args.copy_to) if copy_clean else None
    report = clean_image_dataset(Path(args.data_dir), out_dir=out_dir, copy_clean=copy_clean)

    report_dir = Path(args.report_dir)
    write_cleaning_reports(report, report_dir)
    print(json.dumps({
        "valid_unique_images": report["valid_unique_images"],
        "n_corrupted": report["n_corrupted"],
        "n_unreadable": report["n_unreadable"],
        "n_zero_byte": report["n_zero_byte"],
        "n_unsupported": report["n_unsupported"],
        "n_duplicates": report["n_duplicates"],
        "cleaned_copy_dir": report["cleaned_copy_dir"],
        "report_dir": str(report_dir),
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
