"""Generate a tiny SYNTHETIC smoke-test dataset to verify the pipeline end-to-end.

This is NOT real livestock data. It exists only to prove every code path works
(MobileNetV3 training, XGBoost training, anomaly detection, fusion, explainability).
All generated artifacts are written under data/_smoke/ and clearly labelled as
synthetic in the final report.

Usage:
    python scripts/make_smoke_data.py
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))


def make_synthetic_images(out_dir: Path, n_classes: int = 3, n_per_class: int = 20):
    """Generate simple colored images so MobileNetV3 has something to learn."""
    import numpy as np
    from PIL import Image

    rng = np.random.RandomState(42)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_colors = [
        (220, 60, 60),    # red-ish
        (60, 180, 80),    # green-ish
        (60, 100, 220),   # blue-ish
    ][:n_classes]
    if len(class_colors) < n_classes:
        for _ in range(n_classes - len(class_colors)):
            class_colors.append(tuple(int(c) for c in rng.randint(0, 255, size=3)))
    counts = {}
    for ci, color in enumerate(class_colors):
        cls_dir = out_dir / f"smoke_class_{ci}"
        cls_dir.mkdir(parents=True, exist_ok=True)
        for i in range(n_per_class):
            base = np.full((224, 224, 3), color, dtype=np.uint8)
            noise = rng.randint(-30, 30, size=base.shape).astype(np.int16)
            base = np.clip(base.astype(np.int16) + noise, 0, 255).astype(np.uint8)
            cx, cy = rng.randint(40, 184, size=2)
            base[cy - 10:cy + 10, cx - 10:cx + 10] = 255
            Image.fromarray(base).save(cls_dir / f"img_{i:03d}.jpg")
        counts[f"smoke_class_{ci}"] = n_per_class
    print(f"Generated synthetic images: {counts}")
    return counts


def make_synthetic_clinical(out_csv: Path, n_rows: int = 80):
    """Generate a small CSV with the schema the clinical pipeline expects.

    Columns: age, breed, temperature, symptoms, vaccination_history, disease
    """
    import numpy as np
    rng = np.random.RandomState(42)
    breeds = ["Gir", "Holstein", "Sahiwal", "Jersey"]
    diseases = ["Healthy", "FMD", "Mastitis", "Lumpy"]
    symptoms_by_disease = {
        "Healthy": ["none"],
        "FMD": ["fever,salivation,lameness"],
        "Mastitis": ["swollen_udder,reduced_milk"],
        "Lumpy": ["skin_nodules,fever"],
    }

    rows = []
    for i in range(n_rows):
        disease = rng.choice(diseases, p=[0.4, 0.2, 0.2, 0.2])
        if disease == "Healthy":
            temp = round(float(rng.normal(38.5, 0.3)), 1)
            symptoms = "none"
        else:
            temp = round(float(rng.normal(40.0, 0.6)), 1)
            symptoms = rng.choice(symptoms_by_disease[disease])
        rows.append({
            "animal_id": f"A{i:03d}",
            "age": int(rng.randint(1, 12)),
            "breed": str(rng.choice(breeds)),
            "temperature": temp,
            "symptoms": symptoms,
            "vaccination_history": str(rng.choice(["complete", "partial", "unknown"])),
            "disease": disease,
        })

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"Wrote synthetic clinical CSV: {out_csv} ({n_rows} rows)")


def main():
    images_dir = PROJECT_ROOT / "data" / "_smoke" / "images"
    clinical_csv = PROJECT_ROOT / "data" / "_smoke" / "clinical" / "smoke_clinical.csv"
    make_synthetic_images(images_dir, n_classes=3, n_per_class=20)
    make_synthetic_clinical(clinical_csv, n_rows=80)
    print("Done.")


if __name__ == "__main__":
    main()
