"""Optional outbreak / cluster analytics (spec §34, §35).

ONLY triggered if the dataset contains real latitude / longitude / disease /
date columns. Does NOT manufacture geographic data (spec §34).

Uses DBSCAN for spatial clustering and rolling averages for temporal trends.
Always uses cautious language: 'Detected hotspot', 'Increasing recent case
trend', 'Potential emerging cluster' — never 'will have an outbreak'.

Usage:
    python analytics/disease_clusters.py --data data/clinical/clinical.csv
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402

log = get_logger("analytics")


LAT_LON_CANDIDATES = {
    "lat": ["latitude", "lat", "lat_deg"],
    "lon": ["longitude", "lon", "lng", "long", "lon_deg"],
    "date": ["date", "observation_date", "timestamp", "obs_date", "recorded_at"],
    "disease": ["disease", "diagnosis", "condition", "disease_label", "target"],
}


def find_column(df, kind: str) -> str | None:
    candidates = LAT_LON_CANDIDATES.get(kind, [])
    for c in candidates:
        for col in df.columns:
            if col.lower() == c:
                return col
    for c in candidates:
        for col in df.columns:
            if c in col.lower():
                return col
    return None


def has_geo_data(df) -> bool:
    return find_column(df, "lat") is not None and find_column(df, "lon") is not None


def has_temporal_data(df) -> bool:
    return find_column(df, "date") is not None


def detect_spatial_clusters(df, eps_km: float = 10.0, min_samples: int = 3):
    """Run DBSCAN on lat/lon (converted to radians for haversine metric)."""
    import numpy as np
    from sklearn.cluster import DBSCAN

    lat_col = find_column(df, "lat")
    lon_col = find_column(df, "lon")
    if lat_col is None or lon_col is None:
        return {"error": "Latitude/longitude columns not found."}
    coords = df[[lat_col, lon_col]].dropna().astype(float).to_numpy()
    if coords.size == 0:
        return {"error": "No valid coordinates."}
    # Convert degrees to radians for haversine
    coords_rad = np.radians(coords)
    kms_per_radian = 6371.0088
    eps_rad = eps_km / kms_per_radian
    db = DBSCAN(eps=eps_rad, min_samples=min_samples, metric="haversine")
    labels = db.fit_predict(coords_rad)
    n_clusters = len(set(labels) - {-1})
    n_noise = int((labels == -1).sum())
    # Build cluster summaries
    disease_col = find_column(df, "disease")
    summaries = []
    for cid in sorted(set(labels) - {-1}):
        mask = labels == cid
        cluster_pts = coords[mask]
        centroid_lat = float(cluster_pts[:, 0].mean())
        centroid_lon = float(cluster_pts[:, 1].mean())
        disease_counts: dict[str, int] = {}
        if disease_col:
            sub = df.iloc[np.where(mask)[0]][disease_col].astype(str)
            disease_counts = sub.value_counts().to_dict()
        summaries.append({
            "cluster_id": int(cid),
            "n_points": int(mask.sum()),
            "centroid_lat": centroid_lat,
            "centroid_lon": centroid_lon,
            "disease_counts": {str(k): int(v) for k, v in disease_counts.items()},
        })
    return {
        "n_clusters": n_clusters,
        "n_noise_points": n_noise,
        "eps_km": eps_km,
        "clusters": summaries,
    }


def analyze_temporal_trends(df, window: int = 7):
    """Compute daily/weekly counts and a rolling average per disease."""
    import pandas as pd
    date_col = find_column(df, "date")
    disease_col = find_column(df, "disease")
    if date_col is None:
        return {"error": "No date column found."}
    s = pd.to_datetime(df[date_col], errors="coerce")
    valid = s.notna()
    if not valid.any():
        return {"error": "Could not parse any dates."}
    df = df.loc[valid].copy()
    df["__date"] = s[valid]
    daily = df.groupby(df["__date"].dt.date).size()
    weekly = df.groupby(df["__date"].dt.to_period("W")).size()
    rolling = daily.rolling(window=window, min_periods=1).mean()

    # Per-disease trend
    per_disease: dict = {}
    if disease_col:
        for disease, sub in df.groupby(disease_col):
            sub_daily = sub.groupby(sub["__date"].dt.date).size()
            if len(sub_daily) >= 3:
                recent_mean = float(sub_daily.tail(window).mean())
                earlier_mean = float(sub_daily.head(window).mean()) if len(sub_daily) >= window else 0.0
                trend = "increasing" if recent_mean > earlier_mean else "decreasing"
            else:
                trend = "insufficient_data"
            per_disease[str(disease)] = {
                "n_cases": int(len(sub)),
                "recent_window_mean": recent_mean if 'recent_mean' in dir() else None,
                "trend": trend,
            }

    return {
        "n_records": int(len(df)),
        "date_range": [str(daily.index.min()), str(daily.index.max())],
        "daily_counts": {str(k): int(v) for k, v in daily.items()},
        "weekly_counts": {str(k): int(v) for k, v in weekly.items()},
        "rolling_mean_window_days": window,
        "per_disease_trend": per_disease,
    }


def run_analytics(data_path: Path, reports_dir: Path | None = None,
                 eps_km: float = 10.0, rolling_window: int = 7) -> dict:
    import pandas as pd
    if reports_dir is None:
        reports_dir = PROJECT_ROOT / "reports" / "analytics"
    reports_dir.mkdir(parents=True, exist_ok=True)

    ext = data_path.suffix.lower()
    if ext == ".csv":
        df = pd.read_csv(data_path)
    elif ext == ".xlsx":
        df = pd.read_excel(data_path)
    elif ext == ".parquet":
        df = pd.read_parquet(data_path)
    elif ext == ".json":
        df = pd.read_json(data_path)
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    has_geo = has_geo_data(df)
    has_time = has_temporal_data(df)

    if not has_geo and not has_time:
        log.info(
            "Dataset %s does not contain latitude/longitude/date columns. "
            "Skipping outbreak/cluster analytics (spec §34).", data_path,
        )
        return {"analytics_skipped": True, "reason": "no_geo_or_temporal_columns"}

    result: dict = {"data_path": str(data_path), "n_records": int(len(df))}
    if has_geo:
        log.info("Detecting spatial clusters via DBSCAN (eps=%.1f km).", eps_km)
        result["spatial_clusters"] = detect_spatial_clusters(df, eps_km=eps_km)
    if has_time:
        log.info("Computing temporal trends (rolling window=%d days).", rolling_window)
        result["temporal_trends"] = analyze_temporal_trends(df, window=rolling_window)

    with open(reports_dir / "outbreak_analytics.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, default=str)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Outbreak / cluster analytics (spec §34, §35).")
    parser.add_argument("--data", required=True, type=str)
    parser.add_argument("--eps-km", type=float, default=10.0)
    parser.add_argument("--rolling-window", type=int, default=7)
    args = parser.parse_args(argv)
    result = run_analytics(Path(args.data), eps_km=args.eps_km, rolling_window=args.rolling_window)
    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
