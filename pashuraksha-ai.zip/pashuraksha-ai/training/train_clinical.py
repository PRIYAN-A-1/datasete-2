"""Train XGBoost clinical model (spec §17, §18, §19).

Auto-adapts to binary or multiclass based on detected target cardinality.
Handles imbalance via scale_pos_weight (binary) or sample_weight (multiclass).
Saves preprocessor.joblib + model.joblib + metrics.json + confusion_matrix.png.

Usage:
    python training/train_clinical.py --data data/clinical/clinical.csv
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402
from utils.metrics import (  # noqa: E402
    compute_binary_metrics,
    compute_classification_metrics,
    format_metrics_table,
)
from utils.seed import get_reproducibility_info, set_global_seed  # noqa: E402

log = get_logger("train_clinical")


def train_clinical(
    data_path: Path,
    seed: int = 42,
    model_dir: Path | None = None,
    reports_dir: Path | None = None,
):
    set_global_seed(seed)
    from data_processing.prepare_clinical import prepare_clinical

    if model_dir is None:
        model_dir = PROJECT_ROOT / "models" / "clinical_model"
    if reports_dir is None:
        reports_dir = PROJECT_ROOT / "reports" / "clinical_training"
    model_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    # Prepare features
    log.info("Preparing clinical data from %s", data_path)
    prepared = prepare_clinical(data_path, model_dir, seed=seed)

    X_train, X_val, X_test = prepared["X_train"], prepared["X_val"], prepared["X_test"]
    y_train, y_val, y_test = prepared["y_train"], prepared["y_val"], prepared["y_test"]
    label_classes = prepared["label_classes"]
    n_classes = len(label_classes)
    problem_type = "binary" if n_classes == 2 else "multiclass"
    log.info(
        "Problem: %s, classes=%d, train=%d, val=%d, test=%d",
        problem_type, n_classes, len(y_train), len(y_val), len(y_test),
    )

    # Train XGBoost
    try:
        from xgboost import XGBClassifier
    except ImportError as e:
        raise SystemExit("xgboost is required. Install with `pip install xgboost`.") from e

    from collections import Counter
    params = {
        "n_estimators": 300,
        "max_depth": 6,
        "learning_rate": 0.05,
        "subsample": 0.9,
        "colsample_bytree": 0.9,
        "n_jobs": -1,
        "tree_method": "hist",
        "random_state": seed,
    }
    if problem_type == "binary":
        params["objective"] = "binary:logistic"
        params["eval_metric"] = "logloss"
        # scale_pos_weight for binary imbalance
        counts = Counter(y_train)
        if 0 in counts and 1 in counts and counts[0] > 0:
            params["scale_pos_weight"] = counts[0] / counts[1]
        model = XGBClassifier(**params)
    else:
        params["objective"] = "multi:softprob"
        params["eval_metric"] = "mlogloss"
        params["num_class"] = n_classes
        model = XGBClassifier(**params)

    # Sample weights for multiclass imbalance
    fit_kwargs = {}
    if problem_type == "multiclass":
        counts = Counter(y_train)
        total = sum(counts.values())
        sample_weight = [total / (n_classes * counts[y]) for y in y_train]
        fit_kwargs["sample_weight"] = sample_weight

    model.fit(X_train, y_train, **fit_kwargs)

    # Persist
    import joblib
    joblib.dump(model, model_dir / "model.joblib")
    log.info("Saved model to %s", model_dir / "model.joblib")

    # Evaluate
    if problem_type == "binary":
        y_prob_test = model.predict_proba(X_test)[:, 1]
        y_pred_test = (y_prob_test >= 0.5).astype(int)
        metrics = compute_binary_metrics(y_test, y_pred_test, y_prob=y_prob_test)
        metrics["problem_type"] = "binary"
    else:
        y_prob_test = model.predict_proba(X_test)
        y_pred_test = model.predict(X_test)
        metrics = compute_classification_metrics(
            y_test, y_pred_test, y_prob=y_prob_test, labels=list(range(n_classes)),
        )
        metrics["problem_type"] = "multiclass"

    metrics["label_classes"] = label_classes
    log.info("Clinical test metrics:\n%s", format_metrics_table(metrics))

    with open(reports_dir.parent / "clinical_metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    # Confusion matrix
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
        cm = np.array(metrics.get("confusion_matrix", []))
        if cm.size > 0:
            fig, ax = plt.subplots(figsize=(6, 5), constrained_layout=True)
            im = ax.imshow(cm, cmap="Blues")
            ax.set_xticks(range(len(label_classes)))
            ax.set_yticks(range(len(label_classes)))
            ax.set_xticklabels(label_classes, rotation=45, ha="right")
            ax.set_yticklabels(label_classes)
            ax.set_xlabel("Predicted")
            ax.set_ylabel("True")
            ax.set_title("Clinical model confusion matrix")
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            fig.savefig(reports_dir.parent / "clinical_confusion_matrix.png", dpi=120)
            plt.close(fig)
    except ImportError:
        pass

    # Save training config / reproducibility
    summary = {
        "data_path": str(data_path),
        "target_col": prepared["target_col"],
        "problem_type": problem_type,
        "n_classes": n_classes,
        "label_classes": label_classes,
        "n_features": int(X_train.shape[1]),
        "n_train": int(len(y_train)),
        "n_val": int(len(y_val)),
        "n_test": int(len(y_test)),
        "reproducibility": get_reproducibility_info(seed),
        "params": params,
    }
    with open(reports_dir / "training_config.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)

    return {
        "model": model,
        "metrics": metrics,
        "label_classes": label_classes,
        "problem_type": problem_type,
        "feature_names": prepared["feature_names"],
        "preprocessor_path": prepared["preprocessor_path"],
        "symptom_encoder_path": prepared["symptom_encoder_path"],
        "label_encoder_path": prepared["label_encoder_path"],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train XGBoost clinical model (spec §17–19).")
    parser.add_argument("--data", required=True, type=str)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--model-dir", type=str, default="models/clinical_model")
    parser.add_argument("--reports-dir", type=str, default="reports/clinical_training")
    args = parser.parse_args(argv)
    result = train_clinical(
        data_path=Path(args.data),
        seed=args.seed,
        model_dir=Path(args.model_dir),
        reports_dir=Path(args.reports_dir),
    )
    print(json.dumps({
        "problem_type": result["problem_type"],
        "n_classes": len(result["label_classes"]),
        "label_classes": result["label_classes"],
        "metrics_path": "reports/clinical_metrics.json",
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
