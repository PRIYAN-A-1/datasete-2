"""Evaluate the image classifier on the held-out test set (spec §11).

Loads models/image_model/best_model.pth and runs evaluation on the test split.
Produces:
  reports/image_test_metrics.json
  reports/image_classification_report.csv
  reports/confusion_matrix.png
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.device import get_device  # noqa: E402
from utils.logger import get_logger  # noqa: E402
from utils.metrics import format_metrics_table  # noqa: E402
from utils.seed import set_global_seed  # noqa: E402

log = get_logger("evaluate_image")


def evaluate_image_model(
    model_path: Path,
    data_dir: Path,
    seed: int = 42,
    reports_dir: Path | None = None,
    device_pref: str = "auto",
):
    set_global_seed(seed)
    import torch
    import yaml
    from torch.utils.data import DataLoader
    from torchvision import models

    if reports_dir is None:
        reports_dir = PROJECT_ROOT / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    device = get_device(device_pref, verbose=True)

    if not model_path.exists():
        log.error("Model not found: %s", model_path)
        return None
    payload = torch.load(model_path, map_location=device, weights_only=False)
    class_names = payload["class_names"]
    class_to_idx = payload["class_to_idx"]
    n_classes = len(class_names)

    # Rebuild model architecture
    model = models.mobilenet_v3_large(weights=None)
    in_features = model.classifier[-1].in_features
    model.classifier[-1] = torch.nn.Linear(in_features, n_classes)
    model.load_state_dict(payload["model_state_dict"])
    model.to(device).eval()

    # Build test loader
    with open(PROJECT_ROOT / "configs" / "default.yaml", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    from data_processing.prepare_images import (
        build_eval_transforms,
        collect_image_samples,
        stratified_split,
    )
    from training.train_image import ImageFolderFromCSV  # noqa: E402

    samples = collect_image_samples(Path(data_dir))
    if not samples:
        log.error("No images found in %s", data_dir)
        return None
    split_cfg = cfg.get("image", {}).get("split", {})
    splits = stratified_split(
        samples,
        train=split_cfg.get("train", 0.70),
        val=split_cfg.get("val", 0.15),
        test=split_cfg.get("test", 0.15),
        seed=seed,
    )
    eval_tf = build_eval_transforms(cfg)
    test_ds = ImageFolderFromCSV(splits["test"], class_to_idx, eval_tf)
    test_loader = DataLoader(test_ds, batch_size=32, shuffle=False, num_workers=2)

    import numpy as np
    y_true, y_pred, y_prob = [], [], []
    with torch.no_grad():
        for x, y in test_loader:
            x = x.to(device)
            logits = model(x)
            probs = torch.softmax(logits, dim=1)
            y_true.extend(y.numpy().tolist())
            y_pred.extend(probs.argmax(dim=1).cpu().numpy().tolist())
            y_prob.append(probs.cpu().numpy())

    from utils.metrics import compute_classification_metrics
    y_prob = np.concatenate(y_prob, axis=0) if y_prob else None
    metrics = compute_classification_metrics(
        y_true, y_pred, y_prob=y_prob, labels=list(range(n_classes)),
    )
    log.info("Test metrics:\n%s", format_metrics_table(metrics))

    # Persist
    with open(reports_dir / "image_test_metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    import csv
    with open(reports_dir / "image_classification_report.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["class", "precision", "recall", "f1", "support"])
        for cls, vals in metrics.get("per_class", {}).items():
            w.writerow([cls, vals["precision"], vals["recall"], vals["f1"], vals["support"]])

    # Confusion matrix plot
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        cm = np.array(metrics.get("confusion_matrix", []))
        if cm.size:
            fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
            im = ax.imshow(cm, cmap="Blues")
            ax.set_xticks(range(len(class_names)))
            ax.set_yticks(range(len(class_names)))
            ax.set_xticklabels(class_names, rotation=45, ha="right")
            ax.set_yticklabels(class_names)
            ax.set_xlabel("Predicted")
            ax.set_ylabel("True")
            ax.set_title("Confusion matrix (test set)")
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            fig.savefig(reports_dir / "confusion_matrix.png", dpi=120)
            plt.close(fig)
    except ImportError:
        pass

    return metrics


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Evaluate image classifier (spec §11).")
    parser.add_argument("--model", type=str, default="models/image_model/best_model.pth")
    parser.add_argument("--data-dir", type=str, default="data/images")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args(argv)

    result = evaluate_image_model(
        model_path=Path(args.model),
        data_dir=Path(args.data_dir),
        seed=args.seed,
    )
    if result is None:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
