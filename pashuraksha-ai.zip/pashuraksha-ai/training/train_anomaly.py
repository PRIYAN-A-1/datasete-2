"""Train anomaly detector for image embeddings (spec §21, §22, §23).

Extracts MobileNetV3 penultimate-layer embeddings from the training set and
fits an Isolation Forest (or Local Outlier Factor). Saves a calibration
threshold derived from validation-set anomaly scores (95th percentile by default).

Persisted as models/anomaly_model/image_anomaly.joblib with payload:
  { 'model': iforest, 'threshold': float, 'embedding_dim': int, 'class_names': list }

Usage:
    python training/train_anomaly.py --image-model models/image_model/best_model.pth \
        --data-dir data/images
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.device import get_device  # noqa: E402
from utils.logger import get_logger  # noqa: E402
from utils.seed import set_global_seed  # noqa: E402

log = get_logger("train_anomaly")


def load_image_model(model_path: Path, device: str = "cpu"):
    """Load a trained MobileNetV3 checkpoint and return (model, payload)."""
    from torchvision import models

    payload = torch.load(model_path, map_location=device, weights_only=False)
    arch = payload.get("model_name", "mobilenet_v3_large")
    model = models.mobilenet_v3_large(weights=None)
    in_features = model.classifier[-1].in_features
    n_classes = len(payload["class_names"])
    model.classifier[-1] = torch.nn.Linear(in_features, n_classes)
    model.load_state_dict(payload["model_state_dict"])
    model.to(device)
    model.eval()

    # Replace classifier with identity to expose penultimate features
    model.classifier = torch.nn.Identity()
    return model, payload


def extract_embeddings(model, loader, device: str):
    """Run `model` (with classifier replaced by Identity) and return stacked features."""
    import numpy as np
    feats = []
    with torch.no_grad():
        for x, _ in loader:
            x = x.to(device)
            emb = model(x)
            feats.append(emb.cpu().numpy())
    return np.concatenate(feats, axis=0) if feats else np.empty((0, 0))


def train_image_anomaly(
    model_path: Path,
    data_dir: Path,
    seed: int = 42,
    out_path: Path | None = None,
    technique: str = "isolation_forest",
    contamination: str | float = "auto",
    threshold_quantile: float = 0.95,
):
    set_global_seed(seed)
    import joblib
    import numpy as np

    if out_path is None:
        out_path = PROJECT_ROOT / "models" / "anomaly_model" / "image_anomaly.joblib"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    device = get_device("auto", verbose=True)

    # Build transforms + loaders using the same code path as training
    import yaml
    with open(PROJECT_ROOT / "configs" / "default.yaml", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    from data_processing.prepare_images import (
        build_eval_transforms,
        collect_image_samples,
        stratified_split,
    )
    from torch.utils.data import DataLoader

    from training.train_image import ImageFolderFromCSV  # noqa: E402

    samples = collect_image_samples(data_dir)
    if not samples:
        raise FileNotFoundError(
            f"No images found in {data_dir}. Per spec §58 — refusing to fabricate data."
        )
    classes = sorted({s["class"] for s in samples})
    class_to_idx = {c: i for i, c in enumerate(classes)}
    split_cfg = cfg.get("image", {}).get("split", {})
    splits = stratified_split(
        samples,
        train=split_cfg.get("train", 0.70),
        val=split_cfg.get("val", 0.15),
        test=split_cfg.get("test", 0.15),
        seed=seed,
    )
    eval_tf = build_eval_transforms(cfg)

    train_ds = ImageFolderFromCSV(splits["train"], class_to_idx, eval_tf)
    val_ds = ImageFolderFromCSV(splits["val"], class_to_idx, eval_tf)
    train_loader = DataLoader(train_ds, batch_size=32, shuffle=False, num_workers=2)
    val_loader = DataLoader(val_ds, batch_size=32, shuffle=False, num_workers=2)

    # Load model and strip classifier
    model, payload = load_image_model(model_path, device=device)
    log.info("Loaded image model from %s", model_path)

    # Extract embeddings
    train_emb = extract_embeddings(model, train_loader, device)
    val_emb = extract_embeddings(model, val_loader, device)
    log.info("Train embeddings: %s | Val embeddings: %s", train_emb.shape, val_emb.shape)

    # Fit anomaly detector
    if technique == "isolation_forest":
        from sklearn.ensemble import IsolationForest
        detector = IsolationForest(
            n_estimators=100, contamination=contamination,
            random_state=seed, n_jobs=-1,
        )
        detector.fit(train_emb)
        # Validation-based threshold on anomaly score (-1 * decision_function)
        val_scores = -detector.score_samples(val_emb)
        threshold = float(np.quantile(val_scores, threshold_quantile))
    elif technique == "lof":
        from sklearn.neighbors import LocalOutlierFactor
        detector = LocalOutlierFactor(novelty=True, n_neighbors=20, contamination=contamination)
        detector.fit(train_emb)
        val_scores = -detector.score_samples(val_emb)
        threshold = float(np.quantile(val_scores, threshold_quantile))
    else:
        raise ValueError(f"Unknown technique: {technique}")

    log.info("Anomaly threshold (q=%.2f): %.4f", threshold_quantile, threshold)
    joblib.dump(
        {
            "model": detector,
            "technique": technique,
            "threshold": threshold,
            "embedding_dim": int(train_emb.shape[1]),
            "class_names": classes,
            "threshold_quantile": float(threshold_quantile),
            "val_score_stats": {
                "min": float(val_scores.min()),
                "max": float(val_scores.max()),
                "mean": float(val_scores.mean()),
                "std": float(val_scores.std()),
            },
        },
        out_path,
    )
    log.info("Saved anomaly model to %s", out_path)
    return out_path


# Optional clinical anomaly (spec §23) ------------------------------------
def train_clinical_anomaly(
    data_path: Path,
    seed: int = 42,
    out_path: Path | None = None,
):
    """Train an IsolationForest on processed clinical feature vectors."""
    import joblib
    import numpy as np
    set_global_seed(seed)

    if out_path is None:
        out_path = PROJECT_ROOT / "models" / "anomaly_model" / "clinical_anomaly.joblib"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    from data_processing.prepare_clinical import prepare_clinical
    prepared = prepare_clinical(data_path, PROJECT_ROOT / "models" / "clinical_model", seed=seed)
    X_train = prepared["X_train"]
    X_val = prepared["X_val"]

    from sklearn.ensemble import IsolationForest
    detector = IsolationForest(n_estimators=100, contamination="auto", random_state=seed, n_jobs=-1)
    detector.fit(X_train)
    val_scores = -detector.score_samples(X_val)
    threshold = float(np.quantile(val_scores, 0.95))
    joblib.dump(
        {
            "model": detector,
            "technique": "isolation_forest",
            "threshold": threshold,
            "feature_dim": int(X_train.shape[1]),
            "label_classes": prepared["label_classes"],
        },
        out_path,
    )
    log.info("Saved clinical anomaly model to %s", out_path)
    return out_path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train anomaly detector (spec §21).")
    parser.add_argument("--image-model", type=str, default="models/image_model/best_model.pth")
    parser.add_argument("--data-dir", type=str, default="data/images")
    parser.add_argument("--clinical-data", type=str, default=None,
                        help="Optional clinical CSV path. If provided, also trains a clinical anomaly model.")
    parser.add_argument("--technique", type=str, default="isolation_forest",
                        choices=["isolation_forest", "lof"])
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args(argv)

    image_model_path = Path(args.image_model)
    if image_model_path.exists():
        train_image_anomaly(
            image_model_path, Path(args.data_dir),
            seed=args.seed, technique=args.technique,
        )
    else:
        log.warning(
            "Image model not found at %s — skipping image anomaly training. "
            "Run train_image.py first.", image_model_path,
        )
    if args.clinical_data and Path(args.clinical_data).exists():
        train_clinical_anomaly(Path(args.clinical_data), seed=args.seed)
    return 0


if __name__ == "__main__":
    sys.exit(main())
