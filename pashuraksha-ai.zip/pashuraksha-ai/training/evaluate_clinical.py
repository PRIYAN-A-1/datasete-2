"""Evaluate the clinical XGBoost model on the held-out test set (spec §19)."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.logger import get_logger  # noqa: E402
from utils.metrics import format_metrics_table  # noqa: E402
from utils.seed import set_global_seed  # noqa: E402

log = get_logger("evaluate_clinical")


def evaluate_clinical_model(
    data_path: Path,
    model_dir: Path | None = None,
    reports_dir: Path | None = None,
    seed: int = 42,
):
    set_global_seed(seed)
    import joblib

    if model_dir is None:
        model_dir = PROJECT_ROOT / "models" / "clinical_model"
    if reports_dir is None:
        reports_dir = PROJECT_ROOT / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    model = joblib.load(model_dir / "model.joblib")
    pre = joblib.load(model_dir / "preprocessor.joblib")
    sym_enc = joblib.load(model_dir / "symptom_encoder.joblib")
    le = joblib.load(model_dir / "label_encoder.joblib")
    groups = joblib.load(model_dir / "feature_groups.joblib")

    # Re-run prepare_clinical to obtain the *same* test split (deterministic seed)
    from data_processing.prepare_clinical import prepare_clinical
    prepared = prepare_clinical(data_path, model_dir, seed=seed)

    X_test = prepared["X_test"]
    y_test = prepared["y_test"]
    n_classes = len(le.classes_)

    from utils.metrics import (
        compute_binary_metrics,
        compute_classification_metrics,
    )
    if n_classes == 2:
        y_prob = model.predict_proba(X_test)[:, 1]
        y_pred = (y_prob >= 0.5).astype(int)
        metrics = compute_binary_metrics(y_test, y_pred, y_prob=y_prob)
    else:
        y_prob = model.predict_proba(X_test)
        y_pred = model.predict(X_test)
        metrics = compute_classification_metrics(
            y_test, y_pred, y_prob=y_prob, labels=list(range(n_classes)),
        )
    metrics["label_classes"] = list(le.classes_)
    log.info("Clinical test metrics:\n%s", format_metrics_table(metrics))

    with open(reports_dir / "clinical_metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    return metrics


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Evaluate clinical model (spec §19).")
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--model-dir", type=str, default="models/clinical_model")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args(argv)
    result = evaluate_clinical_model(
        data_path=Path(args.data),
        model_dir=Path(args.model_dir),
        seed=args.seed,
    )
    print(json.dumps({"accuracy": result.get("accuracy")}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
