"""Train MobileNetV3 image classifier (spec §7, §8, §9, §10, §12).

Two-stage transfer learning:
  Stage 1: freeze most backbone layers, train the classification head.
  Stage 2: unfreeze selected later backbone layers, fine-tune with smaller LR.

Class imbalance handled via either class-weighted CrossEntropyLoss or
WeightedRandomSampler (configurable via configs/default.yaml).

Saves best checkpoint to models/image_model/best_model.pth containing:
  model_state_dict, class_names, class_to_idx, model_name, input_size,
  normalization, training_config, best_validation_metric, temperature (calibration),
  reproducibility_info.

Usage:
    python training/train_image.py --data-dir data/processed/images \
        --epochs 50 --batch-size 32 --learning-rate 0.001 --seed 42
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
import time
from pathlib import Path

import torch
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from utils.device import get_device, supports_amp  # noqa: E402
from utils.logger import get_logger  # noqa: E402
from utils.metrics import compute_classification_metrics, format_metrics_table  # noqa: E402
from utils.seed import get_reproducibility_info, set_global_seed  # noqa: E402

log = get_logger("train_image")


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class ImageFolderFromCSV:
    """Dataset that loads images from a list of dicts (path, class, split)."""

    def __init__(self, samples: list[dict], class_to_idx: dict, transform=None):
        import torch
        from PIL import Image
        self.samples = samples
        self.class_to_idx = class_to_idx
        self.transform = transform
        self._Image = Image
        self._torch = torch

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]
        try:
            img = self._Image.open(s["path"]).convert("RGB")
        except Exception as e:  # noqa: BLE001
            log.warning("Failed to open %s: %s — returning placeholder", s["path"], e)
            img = self._Image.new("RGB", (224, 224))
        if self.transform:
            img = self.transform(img)
        return img, self.class_to_idx[s["class"]]


def build_dataloaders(data_dir: Path, cfg: dict, batch_size: int, num_workers: int):
    """Build train/val/test dataloaders from an ImageFolder-style dataset."""
    from data_processing.prepare_images import (
        build_eval_transforms,
        build_train_transforms,
        collect_image_samples,
        stratified_split,
    )

    samples = collect_image_samples(data_dir)
    if not samples:
        raise FileNotFoundError(
            f"No images found in {data_dir}. Per spec §58 — refusing to fabricate data."
        )
    classes = sorted({s["class"] for s in samples})
    if len(classes) < 2:
        raise ValueError(
            f"Need at least 2 classes for classification, found {len(classes)} in {data_dir}."
        )
    class_to_idx = {c: i for i, c in enumerate(classes)}

    split_cfg = cfg.get("image", {}).get("split", {})
    splits = stratified_split(
        samples,
        train=split_cfg.get("train", 0.70),
        val=split_cfg.get("val", 0.15),
        test=split_cfg.get("test", 0.15),
        seed=cfg.get("reproducibility", {}).get("random_seed", 42),
    )

    train_tf = build_train_transforms(cfg)
    eval_tf = build_eval_transforms(cfg)

    import torch
    from torch.utils.data import DataLoader

    train_ds = ImageFolderFromCSV(splits["train"], class_to_idx, train_tf)
    val_ds = ImageFolderFromCSV(splits["val"], class_to_idx, eval_tf)
    test_ds = ImageFolderFromCSV(splits["test"], class_to_idx, eval_tf)

    sampler = None
    if cfg.get("image_model", {}).get("imbalance_strategy") == "weighted_sampler":
        # Compute per-sample weights
        from collections import Counter
        cls_counts = Counter(s["class"] for s in splits["train"])
        weights = [1.0 / cls_counts[s["class"]] for s in splits["train"]]
        sampler = torch.utils.data.WeightedRandomSampler(weights, len(weights), replacement=True)

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=(sampler is None),
        sampler=sampler, num_workers=num_workers, pin_memory=True,
    )
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=True)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=True)

    return {
        "train_loader": train_loader,
        "val_loader": val_loader,
        "test_loader": test_loader,
        "class_names": classes,
        "class_to_idx": class_to_idx,
        "n_train": len(train_ds),
        "n_val": len(val_ds),
        "n_test": len(test_ds),
    }


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

def build_model(num_classes: int, arch: str = "mobilenet_v3_large", pretrained: bool = True):
    """Build a MobileNetV3 model with a replaced classification head."""
    import torch
    from torchvision import models

    try:
        weights = models.MobileNet_V3_Large_Weights.IMAGENET1K_V1 if pretrained else None
        model = models.mobilenet_v3_large(weights=weights)
    except Exception:
        # Older torchvision fallback
        model = models.mobilenet_v3_large(pretrained=pretrained)

    in_features = model.classifier[-1].in_features
    model.classifier[-1] = torch.nn.Linear(in_features, num_classes)
    return model


def freeze_backbone(model, freeze: bool = True):
    """Freeze all backbone params (Stage 1) or unfreeze them (Stage 2)."""
    for p in model.parameters():
        p.requires_grad = not freeze
    # Always keep classifier trainable
    for p in model.classifier.parameters():
        p.requires_grad = True


def unfreeze_later_layers(model, fraction: float = 0.3):
    """Unfreeze the last `fraction` of the backbone for Stage 2 fine-tuning."""
    children = list(model.features.children())
    n_unfreeze = max(1, int(len(children) * fraction))
    for layer in children[-n_unfreeze:]:
        for p in layer.parameters():
            p.requires_grad = True


# ---------------------------------------------------------------------------
# Training utilities
# ---------------------------------------------------------------------------

def compute_class_weights(loader, num_classes: int):
    """Inverse-frequency class weights for class-weighted CrossEntropyLoss."""
    from collections import Counter
    counts = Counter()
    for _, y in loader:
        for v in y.tolist():
            counts[int(v)] += 1
    weights = [1.0 / max(counts.get(i, 1), 1) for i in range(num_classes)]
    total = sum(weights)
    weights = [w / total * num_classes for w in weights]
    return weights


def train_one_epoch(model, loader, optimizer, criterion, device, scaler=None):
    import torch
    model.train()
    running_loss, correct, total = 0.0, 0, 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        if scaler is not None and supports_amp(device):
            with torch.amp.autocast(device_type=device):
                logits = model(x)
                loss = criterion(logits, y)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()
        running_loss += loss.item() * x.size(0)
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += x.size(0)
    return running_loss / max(total, 1), correct / max(total, 1)


@torch.no_grad
def evaluate(model, loader, criterion, device, num_classes: int):
    import numpy as np
    model.eval()
    running_loss, correct, total = 0.0, 0, 0
    y_true, y_pred, y_prob = [], [], []
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        loss = criterion(logits, y)
        running_loss += loss.item() * x.size(0)
        probs = torch.softmax(logits, dim=1)
        pred = probs.argmax(dim=1)
        correct += (pred == y).sum().item()
        total += x.size(0)
        y_true.extend(y.cpu().numpy().tolist())
        y_pred.extend(pred.cpu().numpy().tolist())
        y_prob.append(probs.cpu().numpy())
    y_prob = np.concatenate(y_prob, axis=0) if y_prob else None
    metrics = compute_classification_metrics(
        y_true, y_pred, y_prob=y_prob, labels=list(range(num_classes)),
    )
    metrics["loss"] = running_loss / max(total, 1)
    metrics["accuracy"] = correct / max(total, 1)
    return metrics


class EarlyStopping:
    def __init__(self, patience: int = 6, metric: str = "macro_f1", mode: str = "max"):
        self.patience = patience
        self.metric = metric
        self.mode = mode
        self.best = -float("inf") if mode == "max" else float("inf")
        self.counter = 0
        self.should_stop = False

    def step(self, value: float) -> bool:
        improved = (self.mode == "max" and value > self.best) or (self.mode == "min" and value < self.best)
        if improved:
            self.best = value
            self.counter = 0
            return True
        self.counter += 1
        if self.counter >= self.patience:
            self.should_stop = True
        return False


# ---------------------------------------------------------------------------
# Calibration (spec §12)
# ---------------------------------------------------------------------------

class TemperatureScaler:
    """Simple temperature scaling for post-hoc softmax calibration."""

    def __init__(self):
        import torch
        self.temperature = torch.nn.Parameter(torch.ones(1) * 1.5)

    def fit(self, logits, y_true, device="cpu", max_iter: int = 100, lr: float = 0.01):
        import torch
        self.temperature.data = torch.ones(1, device=device) * 1.5
        opt = torch.optim.LBFGS([self.temperature], lr=lr, max_iter=max_iter)
        logits = logits.to(device)
        y_true = y_true.to(device)

        def closure():
            opt.zero_grad()
            scaled = logits / self.temperature
            loss = torch.nn.functional.cross_entropy(scaled, y_true)
            loss.backward()
            return loss
        opt.step(closure)
        return float(self.temperature.item())

    def apply(self, logits):
        import torch
        return torch.softmax(logits / self.temperature.to(logits.device), dim=1)


def expected_calibration_error(y_true, y_prob, n_bins: int = 10):
    """Compute Expected Calibration Error (spec §12)."""
    import numpy as np
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    confidences = y_prob.max(axis=1)
    predictions = y_prob.argmax(axis=1)
    accuracies = (predictions == y_true).astype(float)
    bin_edges = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    for i in range(n_bins):
        lo, hi = bin_edges[i], bin_edges[i + 1]
        mask = (confidences > lo) & (confidences <= hi)
        if mask.sum() == 0:
            continue
        avg_conf = confidences[mask].mean()
        avg_acc = accuracies[mask].mean()
        ece += abs(avg_conf - avg_acc) * mask.sum() / len(y_true)
    return float(ece)


# ---------------------------------------------------------------------------
# Main training loop
# ---------------------------------------------------------------------------

def train_image(
    data_dir: Path,
    epochs: int = 50,
    batch_size: int = 32,
    learning_rate: float = 1e-3,
    seed: int = 42,
    num_workers: int = 4,
    device_pref: str = "auto",
    config_path: Path | None = None,
    out_dir: Path | None = None,
):
    set_global_seed(seed)
    cfg = {}
    if config_path and Path(config_path).exists():
        with open(config_path, encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    if out_dir is None:
        out_dir = PROJECT_ROOT / "models" / "image_model"
    out_dir.mkdir(parents=True, exist_ok=True)
    reports_dir = PROJECT_ROOT / "reports" / "image_training"
    reports_dir.mkdir(parents=True, exist_ok=True)

    device = get_device(device_pref, verbose=True)

    try:
        import torch
        from torch.utils.data import DataLoader
        from torchvision import models
    except ImportError as e:
        raise SystemExit("PyTorch / torchvision is required for image training.") from e

    # Build loaders
    try:
        data = build_dataloaders(Path(data_dir), cfg, batch_size, num_workers)
    except FileNotFoundError as e:
        log.error(str(e))
        return None

    train_loader = data["train_loader"]
    val_loader = data["val_loader"]
    test_loader = data["test_loader"]
    class_names = data["class_names"]
    class_to_idx = data["class_to_idx"]
    num_classes = len(class_names)
    log.info(
        "Train=%d Val=%d Test=%d Classes=%d",
        data["n_train"], data["n_val"], data["n_test"], num_classes,
    )

    # Model
    arch = cfg.get("image_model", {}).get("arch", "mobilenet_v3_large")
    pretrained = cfg.get("image_model", {}).get("pretrained", True)
    model = build_model(num_classes=num_classes, arch=arch, pretrained=pretrained)
    model = model.to(device)

    # Loss + optimizer
    imb_strategy = cfg.get("image_model", {}).get("imbalance_strategy", "weighted_loss")
    if imb_strategy == "weighted_loss":
        weights = compute_class_weights(train_loader, num_classes)
        cw_tensor = torch.tensor(weights, dtype=torch.float, device=device)
        criterion = torch.nn.CrossEntropyLoss(weight=cw_tensor)
    else:
        criterion = torch.nn.CrossEntropyLoss()

    # Stage 1: head-only
    stage1_epochs = cfg.get("image_model", {}).get("stage1_epochs", 5)
    stage2_epochs = epochs - stage1_epochs
    finetune_lr = cfg.get("image_model", {}).get("finetune_lr", 1e-4)
    patience = cfg.get("image_model", {}).get("early_stopping_patience", 6)
    es_metric = cfg.get("image_model", {}).get("early_stopping_metric", "macro_f1")

    # Training history
    history = {
        "train_loss": [], "val_loss": [],
        "train_acc": [], "val_acc": [],
        "val_macro_f1": [], "lr": [],
    }

    best_state = None
    best_metric_value = -float("inf") if es_metric != "val_loss" else float("inf")
    early = EarlyStopping(patience=patience, metric=es_metric,
                          mode="min" if es_metric == "val_loss" else "max")

    scaler = torch.amp.GradScaler(device) if (supports_amp(device) and cfg.get("image_model", {}).get("amp_enabled", True)) else None

    def run_stage(stage_name: str, epochs_stage: int, lr: float, freeze: bool, unfreeze_frac: float = 0.0):
        nonlocal best_state, best_metric_value
        if freeze:
            freeze_backbone(model, freeze=True)
        else:
            freeze_backbone(model, freeze=False)
            if unfreeze_frac > 0:
                unfreeze_later_layers(model, fraction=unfreeze_frac)
        params = [p for p in model.parameters() if p.requires_grad]
        optimizer = torch.optim.AdamW(params, lr=lr, weight_decay=cfg.get("image_model", {}).get("weight_decay", 0.01))
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(epochs_stage, 1))

        log.info("[%s] %d epochs, lr=%g, trainable params=%d",
                 stage_name, epochs_stage, lr, sum(p.numel() for p in params if p.requires_grad))
        for ep in range(epochs_stage):
            t0 = time.time()
            tr_loss, tr_acc = train_one_epoch(model, train_loader, optimizer, criterion, device, scaler=scaler)
            val_metrics = evaluate(model, val_loader, criterion, device, num_classes)
            scheduler.step()
            history["train_loss"].append(tr_loss)
            history["val_loss"].append(val_metrics["loss"])
            history["train_acc"].append(tr_acc)
            history["val_acc"].append(val_metrics["accuracy"])
            history["val_macro_f1"].append(val_metrics.get("macro_f1", 0.0))
            history["lr"].append(optimizer.param_groups[0]["lr"])
            log.info(
                "[%s epoch %02d] train_loss=%.4f val_loss=%.4f val_acc=%.4f val_f1=%.4f (%.1fs)",
                stage_name, ep + 1, tr_loss, val_metrics["loss"], val_metrics["accuracy"],
                val_metrics.get("macro_f1", 0.0), time.time() - t0,
            )
            current = val_metrics["loss"] if es_metric == "val_loss" else val_metrics.get(es_metric, 0.0)
            improved = early.step(current)
            if improved:
                best_metric_value = current
                best_state = copy.deepcopy(model.state_dict())
                # Save best checkpoint immediately
                _save_checkpoint(
                    model, best_state, class_names, class_to_idx,
                    arch, cfg, best_metric_value, es_metric, out_dir / "best_model.pth",
                    temperature=None,
                )
            if early.should_stop:
                log.info("Early stopping triggered at epoch %d (patience=%d).", ep + 1, patience)
                break

    # Run stages
    run_stage("stage1", stage1_epochs, learning_rate, freeze=True)
    if stage2_epochs > 0:
        run_stage("stage2", stage2_epochs, finetune_lr, freeze=False, unfreeze_frac=0.3)

    # Restore best
    if best_state is not None:
        model.load_state_dict(best_state)

    # Calibration on validation set
    temperature_value = None
    ece_before = None
    ece_after = None
    if cfg.get("image_model", {}).get("calibration", {}).get("enabled", True):
        try:
            # Collect validation logits
            model.eval()
            all_logits, all_y = [], []
            with torch.no_grad():
                for x, y in val_loader:
                    x = x.to(device)
                    logits = model(x)
                    all_logits.append(logits.cpu())
                    all_y.append(y)
            all_logits = torch.cat(all_logits, dim=0)
            all_y = torch.cat(all_y, dim=0)
            probs_before = torch.softmax(all_logits, dim=1).detach().cpu().numpy()
            ece_before = expected_calibration_error(all_y.numpy(), probs_before)
            scaler_c = TemperatureScaler()
            temperature_value = scaler_c.fit(all_logits.detach(), all_y, device=device)
            probs_after = scaler_c.apply(all_logits).detach().cpu().numpy()
            ece_after = expected_calibration_error(all_y.numpy(), probs_after)
            log.info("Calibration: temperature=%.4f ECE %.4f -> %.4f", temperature_value, ece_before, ece_after)
            _save_checkpoint(
                model, best_state, class_names, class_to_idx,
                arch, cfg, best_metric_value, es_metric, out_dir / "best_model.pth",
                temperature=temperature_value,
            )
        except Exception as e:  # noqa: BLE001
            log.warning("Calibration step skipped: %s", e)

    # Test evaluation
    test_metrics = evaluate(model, test_loader, criterion, device, num_classes)
    log.info("Test metrics:\n%s", format_metrics_table(test_metrics))

    # Save history & test metrics
    with open(reports_dir / "training_history.json", "w", encoding="utf-8") as f:
        json.dump({
            "history": history,
            "best_metric": best_metric_value,
            "metric_name": es_metric,
            "ece_before": ece_before,
            "ece_after": ece_after,
            "temperature": temperature_value,
            "reproducibility": get_reproducibility_info(seed),
            "test_metrics": test_metrics,
        }, f, indent=2)

    _plot_training_curves(history, reports_dir)
    _plot_confusion_matrix(test_metrics, class_names, reports_dir)

    # Save per-class CSV report
    import csv
    with open(reports_dir / "classification_report.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["class", "precision", "recall", "f1", "support"])
        for cls, vals in test_metrics.get("per_class", {}).items():
            w.writerow([cls, vals["precision"], vals["recall"], vals["f1"], vals["support"]])
    with open(reports_dir.parent / "image_test_metrics.json", "w", encoding="utf-8") as f:
        json.dump(test_metrics, f, indent=2)
    with open(reports_dir.parent / "image_classification_report.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["class", "precision", "recall", "f1", "support"])
        for cls, vals in test_metrics.get("per_class", {}).items():
            w.writerow([cls, vals["precision"], vals["recall"], vals["f1"], vals["support"]])

    # Confusion matrix PNG at reports root
    _plot_confusion_matrix(test_metrics, class_names, reports_dir.parent, filename="confusion_matrix.png")

    return {
        "model": model,
        "class_names": class_names,
        "class_to_idx": class_to_idx,
        "best_metric_value": best_metric_value,
        "test_metrics": test_metrics,
        "history": history,
        "temperature": temperature_value,
        "ece_before": ece_before,
        "ece_after": ece_after,
    }


# ---------------------------------------------------------------------------
# Checkpoint I/O
# ---------------------------------------------------------------------------

def _save_checkpoint(model, state_dict, class_names, class_to_idx, arch, cfg,
                     best_metric, metric_name, path: Path, temperature=None):
    import torch
    image_cfg = cfg.get("image", {})
    payload = {
        "model_state_dict": state_dict,
        "class_names": class_names,
        "class_to_idx": class_to_idx,
        "model_name": arch,
        "input_size": image_cfg.get("input_size", 224),
        "normalization": image_cfg.get("normalization", {}),
        "training_config": cfg,
        "best_validation_metric": {
            "name": metric_name,
            "value": float(best_metric) if best_metric is not None else None,
        },
        "temperature": float(temperature) if temperature is not None else None,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, path)


# ---------------------------------------------------------------------------
# Plots
# ---------------------------------------------------------------------------

def _plot_training_curves(history: dict, reports_dir: Path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        log.warning("matplotlib unavailable; skipping training plots.")
        return
    plots = [
        ("train_loss", "val_loss", "Loss", "loss_curve.png"),
        ("train_acc", "val_acc", "Accuracy", "accuracy_curve.png"),
        (None, "val_macro_f1", "Macro F1", "f1_curve.png"),
        (None, "lr", "Learning rate", "learning_rate_curve.png"),
    ]
    for a, b, ylabel, fname in plots:
        fig, ax = plt.subplots(figsize=(8, 4.5), constrained_layout=True)
        if a is not None and a in history:
            ax.plot(history[a], label=f"train {ylabel.lower()}")
        if b is not None and b in history:
            ax.plot(history[b], label=f"val {ylabel.lower()}")
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        ax.set_title(f"{ylabel} curve")
        ax.legend(loc="best")
        fig.savefig(reports_dir / fname, dpi=120)
        plt.close(fig)


def _plot_confusion_matrix(metrics: dict, class_names: list[str], reports_dir: Path,
                            filename: str = "confusion_matrix.png"):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        return
    cm = np.array(metrics.get("confusion_matrix", []))
    if cm.size == 0:
        return
    labels = class_names or metrics.get("labels", [])
    fig, axes = plt.subplots(1, 2, figsize=(14, 6), constrained_layout=True)
    for ax, norm, title in zip(axes, [False, True], ["Confusion matrix", "Normalized"]):
        m = cm.astype(float)
        if norm:
            row_sums = m.sum(axis=1, keepdims=True)
            row_sums[row_sums == 0] = 1
            m = m / row_sums
        im = ax.imshow(m, cmap="Blues")
        ax.set_xticks(range(len(labels)))
        ax.set_yticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=45, ha="right")
        ax.set_yticklabels(labels)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.set_title(title)
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.savefig(reports_dir / filename, dpi=120)
    plt.close(fig)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train MobileNetV3 image classifier (spec §7–§10).")
    parser.add_argument("--data-dir", required=True, type=str)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--config", type=str, default=str(PROJECT_ROOT / "configs" / "default.yaml"))
    args = parser.parse_args(argv)

    if args.epochs > 50:
        log.warning("Capping epochs at 50 per spec §8.")
        args.epochs = 50
    if args.epochs <= 5:
        log.warning("Need at least 6 epochs for two-stage training; bumping to 6.")
        args.epochs = 6

    result = train_image(
        data_dir=Path(args.data_dir),
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        seed=args.seed,
        num_workers=args.num_workers,
        device_pref=args.device,
        config_path=Path(args.config),
    )
    if result is None:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
