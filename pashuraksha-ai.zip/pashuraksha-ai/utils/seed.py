"""Global seeding utilities for reproducibility.

Implements spec §36 — seeds for Python random, NumPy, PyTorch, CUDA, plus
deterministic cuDNN options where reasonable.
"""
from __future__ import annotations

import os
import random
import sys


def set_global_seed(seed: int = 42) -> None:
    """Set Python, NumPy, and PyTorch seeds deterministically.

    Also configures cuDNN to be deterministic (slower, but reproducible).
    Safe to call even if torch is not installed.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)

    try:
        import numpy as np

        np.random.seed(seed)
    except ImportError:
        pass

    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)
        # cuDNN determinism
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


def get_reproducibility_info(seed: int = 42) -> dict:
    """Return a metadata dict recording seed, Python version, package versions.

    Used in saved checkpoints and final reports (spec §36).
    """
    import platform

    info: dict = {
        "random_seed": seed,
        "python_version": sys.version,
        "platform": platform.platform(),
        "packages": {},
    }

    packages = [
        "torch",
        "torchvision",
        "numpy",
        "pandas",
        "scikit-learn",
        "xgboost",
        "opencv-python",
        "PIL",
        "matplotlib",
        "imbalanced-learn",
        "joblib",
        "shap",
        "scipy",
        "tqdm",
        "yaml",
    ]
    import importlib.metadata as md

    for pkg in packages:
        dist_name = pkg.replace("PIL", "Pillow").replace("opencv-python", "opencv-python")
        try:
            info["packages"][pkg] = md.version(dist_name)
        except md.PackageNotFoundError:
            info["packages"][pkg] = "not-installed"
    return info


if __name__ == "__main__":
    set_global_seed(42)
    print(get_reproducibility_info(42))
