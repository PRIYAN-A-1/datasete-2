"""Device selection utilities (spec §39).

Auto-detects CUDA > Apple MPS > CPU. Prints selected device before training.
"""
from __future__ import annotations

from typing import Optional


def get_device(preference: str = "auto", verbose: bool = True) -> str:
    """Return a device string suitable for PyTorch.

    Parameters
    ----------
    preference:
        One of "auto", "cuda", "mps", "cpu".
        "auto" tries CUDA first, then MPS, then CPU.
    verbose:
        If True, prints the selected device.
    """
    preference = (preference or "auto").lower()

    try:
        import torch
    except ImportError:
        if verbose:
            print("[device] PyTorch not installed — falling back to CPU.")
        return "cpu"

    available: list[str] = []
    if torch.cuda.is_available():
        available.append("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        available.append("mps")
    available.append("cpu")

    if preference == "auto":
        device = available[0]
    elif preference in available:
        device = preference
    else:
        # User explicitly asked for something unavailable.
        device = available[0]
        if verbose:
            print(
                f"[device] Requested '{preference}' is unavailable on this "
                f"machine; using '{device}'."
            )

    if verbose:
        gpu_name = ""
        if device == "cuda":
            try:
                gpu_name = f" ({torch.cuda.get_device_name(0)})"
            except Exception:
                pass
        print(f"[device] Selected device: {device}{gpu_name}")

    return device


def supports_amp(device: str) -> bool:
    """Return True if mixed-precision training is supported on this device."""
    return device == "cuda"


if __name__ == "__main__":
    get_device()
