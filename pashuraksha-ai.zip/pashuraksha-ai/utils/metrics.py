"""Classification metrics — wraps sklearn to satisfy spec §11 and §19.

Returns a single dict suitable for JSON serialization in `reports/*_metrics.json`.
"""
from __future__ import annotations

from typing import Any

import numpy as np


def compute_classification_metrics(
    y_true, y_pred, y_prob=None, labels=None
) -> dict[str, Any]:
    """Compute the metric set required by spec §11.

    Includes accuracy, balanced accuracy, macro / weighted precision/recall/F1,
    per-class precision/recall/F1/support, plus ROC-AUC for binary or multiclass
    when probabilities are supplied.
    """
    from sklearn.metrics import (
        accuracy_score,
        balanced_accuracy_score,
        classification_report,
        confusion_matrix,
        precision_recall_fscore_support,
        roc_auc_score,
    )

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    labels = list(labels) if labels is not None else sorted(set(y_true) | set(y_pred))

    metrics: dict[str, Any] = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
    }

    p_macro, r_macro, f1_macro, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="macro", zero_division=0
    )
    p_w, r_w, f1_w, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="weighted", zero_division=0
    )
    metrics.update(
        {
            "macro_precision": float(p_macro),
            "macro_recall": float(r_macro),
            "macro_f1": float(f1_macro),
            "weighted_precision": float(p_w),
            "weighted_recall": float(r_w),
            "weighted_f1": float(f1_w),
        }
    )

    # Per-class
    p_class, r_class, f1_class, s_class = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average=None, zero_division=0
    )
    metrics["per_class"] = {
        str(lbl): {
            "precision": float(p_class[i]),
            "recall": float(r_class[i]),
            "f1": float(f1_class[i]),
            "support": int(s_class[i]),
        }
        for i, lbl in enumerate(labels)
    }

    metrics["confusion_matrix"] = confusion_matrix(y_true, y_pred, labels=labels).tolist()
    metrics["labels"] = [str(l) for l in labels]

    # ROC-AUC
    if y_prob is not None:
        y_prob = np.asarray(y_prob)
        try:
            if len(labels) == 2:
                # binary — use probability of positive class
                p1 = y_prob[:, 1] if y_prob.ndim == 2 else y_prob
                metrics["roc_auc"] = float(roc_auc_score(y_true, p1))
            else:
                metrics["roc_auc_ovr"] = float(
                    roc_auc_score(
                        y_true, y_prob, multi_class="ovr", average="macro",
                        labels=labels,
                    )
                )
        except Exception as e:  # noqa: BLE001
            metrics["roc_auc_error"] = str(e)
    return metrics


def compute_binary_metrics(y_true, y_pred, y_prob=None) -> dict[str, Any]:
    """Compute binary-classification metrics including ROC-AUC and PR-AUC."""
    from sklearn.metrics import (
        accuracy_score,
        average_precision_score,
        balanced_accuracy_score,
        confusion_matrix,
        precision_recall_fscore_support,
        roc_auc_score,
    )

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    p, r, f1, s = precision_recall_fscore_support(
        y_true, y_pred, average="binary", zero_division=0
    )
    out: dict[str, Any] = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "precision": float(p),
        "recall": float(r),
        "f1": float(f1),
        "support": int(s),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
    }
    if y_prob is not None:
        y_prob = np.asarray(y_prob)
        try:
            out["roc_auc"] = float(roc_auc_score(y_true, y_prob))
            out["pr_auc"] = float(average_precision_score(y_true, y_prob))
        except Exception as e:  # noqa: BLE001
            out["auc_error"] = str(e)
    return out


def compute_multiclass_metrics(y_true, y_pred, y_prob=None, labels=None) -> dict[str, Any]:
    """Wrapper that always returns multiclass metrics."""
    return compute_classification_metrics(y_true, y_pred, y_prob=y_prob, labels=labels)


def format_metrics_table(metrics: dict[str, Any]) -> str:
    """Human-readable text table of metrics for printing to stdout."""
    lines = []
    for key in [
        "accuracy",
        "balanced_accuracy",
        "macro_precision",
        "macro_recall",
        "macro_f1",
        "weighted_precision",
        "weighted_recall",
        "weighted_f1",
        "roc_auc",
        "roc_auc_ovr",
    ]:
        if key in metrics:
            lines.append(f"  {key:<25} {metrics[key]:.4f}")
    if "per_class" in metrics:
        lines.append("\n  Per-class:")
        lines.append(f"    {'class':<20} {'precision':>10} {'recall':>10} {'f1':>10} {'support':>10}")
        for cls, vals in metrics["per_class"].items():
            lines.append(
                f"    {cls:<20} {vals['precision']:>10.4f} {vals['recall']:>10.4f} "
                f"{vals['f1']:>10.4f} {vals['support']:>10d}"
            )
    return "\n".join(lines)
